
import React, { useState, useMemo, useEffect } from 'react';
import { Grievance, Application, Village, Tab, User, Bill, CertificateRequest, Scheme } from '../types';
import { VillageDirectory } from './VillageDirectory';
import { PANCHAYAT_SCHEMES } from './Schemes';

// Mock Data
const MOCK_GRIEVANCES: Grievance[] = [
  { id: 'g1', subject: 'Broken Streetlight', description: 'Streetlight pole #45 near Main Market is not working.', status: 'Pending', date: '2023-10-25', submittedBy: 'Ramesh Kumar' },
  { id: 'g2', subject: 'Water Leakage', description: 'Pipeline leak near School Road causing mud.', status: 'Pending', date: '2023-10-26', submittedBy: 'Suresh Patil' },
  { id: 'g3', subject: 'Garbage Collection', description: 'Garbage not collected for 3 days in Ward 2.', status: 'Resolved', date: '2023-10-20', submittedBy: 'Lakshmi Devi' },
];

const MOCK_APPLICATIONS: Application[] = [
  { id: 'a1', schemeName: 'MGNREGA', applicantName: 'Basavaraj H', status: 'Pending', date: '2023-10-27' },
  { id: 'a2', schemeName: 'PMAY-G (Housing)', applicantName: 'Channamma K', status: 'Pending', date: '2023-10-26' },
  { id: 'a3', schemeName: 'Old Age Pension', applicantName: 'Shivanna', status: 'Approved', date: '2023-10-22' },
];

interface AdminDashboardProps {
  village: Village;
  allVillages: Village[];
  onSelectVillage: (v: Village) => void;
  onLogout: () => void;
  adminPanchayatName?: string;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ village, allVillages, onSelectVillage, onLogout, adminPanchayatName }) => {
  const [activeTab, setActiveTab] = useState<Tab>(Tab.ADMIN_OVERVIEW);
  const [grievances, setGrievances] = useState(MOCK_GRIEVANCES);
  const [applications, setApplications] = useState(MOCK_APPLICATIONS);

  // Bill Generation State
  const [selectedCitizenId, setSelectedCitizenId] = useState('');
  const [billType, setBillType] = useState('Property Tax');
  const [billAmount, setBillAmount] = useState('');
  const [billDueDate, setBillDueDate] = useState('');

  // Certificate State
  const [certRequests, setCertRequests] = useState<CertificateRequest[]>([]);
  const [selectedRequest, setSelectedRequest] = useState<CertificateRequest | null>(null);
  
  // Generator form state (pre-filled from request)
  const [certType, setCertType] = useState('Birth Certificate');
  const [certName, setCertName] = useState('');
  const [certAadhaar, setCertAadhaar] = useState('');
  const [generatedCert, setGeneratedCert] = useState<{type: string, name: string, aadhaar: string, date: string, id: string} | null>(null);
  const [manualCertCitizenId, setManualCertCitizenId] = useState('');

  // Schemes State
  const [customSchemes, setCustomSchemes] = useState<Scheme[]>([]);
  const [newScheme, setNewScheme] = useState<Partial<Scheme>>({ category: 'Agriculture' });

  // Filter villages based on admin's panchayat name if available
  const managedVillages = useMemo(() => {
    if (!adminPanchayatName) return allVillages;
    return allVillages.filter(v => v.panchayat.toLowerCase().includes(adminPanchayatName.toLowerCase()));
  }, [allVillages, adminPanchayatName]);

  // Retrieve registered citizens filtered by the admin's panchayat
  const registeredCitizens = useMemo(() => {
    try {
        const usersStr = localStorage.getItem('gramuday_users');
        if (!usersStr) return [];
        const users = JSON.parse(usersStr) as User[];
        if (!adminPanchayatName) return [];
        // Filter citizens belonging to this panchayat (case-insensitive)
        return users.filter(u => 
            u.role === 'citizen' && 
            u.panchayatName?.toLowerCase() === adminPanchayatName.toLowerCase()
        );
    } catch (e) { return []; }
  }, [adminPanchayatName, activeTab]);

  const issuedBills = useMemo(() => {
      try {
          const billsStr = localStorage.getItem('gramuday_bills');
          if (!billsStr) return [];
          const bills = JSON.parse(billsStr) as Bill[];
          return bills.filter(b => b.panchayat === adminPanchayatName).sort((a,b) => new Date(b.issuedDate).getTime() - new Date(a.issuedDate).getTime());
      } catch (e) { return []; }
  }, [adminPanchayatName, activeTab]); 

  // Load Certificate Requests
  useEffect(() => {
      if (activeTab === Tab.CERTIFICATES && adminPanchayatName) {
          try {
              const stored = localStorage.getItem('gramuday_certificate_requests');
              if (stored) {
                  const allReq = JSON.parse(stored) as CertificateRequest[];
                  const myReq = allReq.filter(r => r.panchayat === adminPanchayatName && r.status === 'Pending');
                  setCertRequests(myReq);
              }
          } catch(e) {}
      }
  }, [activeTab, adminPanchayatName]);

  // Load Schemes
  useEffect(() => {
      if (activeTab === Tab.SCHEMES) {
          try {
              const stored = localStorage.getItem('gramuday_custom_schemes');
              if (stored) {
                  setCustomSchemes(JSON.parse(stored));
              }
          } catch(e) {}
      }
  }, [activeTab]);

  const resolveGrievance = (id: string) => {
    setGrievances(prev => prev.map(g => g.id === id ? { ...g, status: 'Resolved' } : g));
  };

  const processApplication = (id: string, status: 'Approved' | 'Rejected') => {
    setApplications(prev => prev.map(a => a.id === id ? { ...a, status } : a));
  };

  const handleIssueBill = (e: React.FormEvent) => {
      e.preventDefault();
      if (!selectedCitizenId || !billAmount || !billDueDate || !adminPanchayatName) return;

      const citizen = registeredCitizens.find(c => c.email === selectedCitizenId);
      if (!citizen) return;

      const newBill: Bill = {
          id: `BILL-${Date.now()}`,
          citizenEmail: citizen.email,
          citizenName: citizen.name,
          panchayat: adminPanchayatName,
          type: billType as any,
          amount: parseFloat(billAmount),
          dueDate: billDueDate,
          issuedDate: new Date().toISOString().split('T')[0],
          status: 'Pending'
      };

      try {
          const existingBillsStr = localStorage.getItem('gramuday_bills');
          const existingBills = existingBillsStr ? JSON.parse(existingBillsStr) : [];
          existingBills.push(newBill);
          localStorage.setItem('gramuday_bills', JSON.stringify(existingBills));
          alert("Bill issued successfully!");
          // Reset form
          setBillAmount('');
          setBillDueDate('');
          setSelectedCitizenId('');
          // Force re-render of list by toggling tab slightly or using state (handled by useMemo dep on activeTab mostly, but better to force update)
          setActiveTab(Tab.BILLS); 
      } catch(e) {
          alert("Failed to save bill.");
      }
  };

  const selectRequestForProcessing = (req: CertificateRequest) => {
      setSelectedRequest(req);
      setCertType(req.type);
      setCertName(req.citizenName);
      setCertAadhaar(req.aadhaar);
      setGeneratedCert(null);
  };

  const resetCertificateForm = () => {
      setSelectedRequest(null);
      setGeneratedCert(null);
      setCertName('');
      setCertAadhaar('');
      setManualCertCitizenId('');
  };

  const handleGenerateCertificate = () => {
    if (!certName || !certAadhaar) {
      alert("Please enter Applicant Name and Aadhaar Number.");
      return;
    }
    
    const newCert = {
      type: certType,
      name: certName,
      aadhaar: certAadhaar,
      date: new Date().toLocaleDateString(),
      id: `GOV-${Math.floor(Math.random() * 100000)}`
    };
    
    setGeneratedCert(newCert);

    // 1. If processing a REQUEST
    if (selectedRequest) {
        try {
            const stored = localStorage.getItem('gramuday_certificate_requests');
            if (stored) {
                let allReq = JSON.parse(stored) as CertificateRequest[];
                allReq = allReq.map(r => r.id === selectedRequest.id ? { 
                    ...r, 
                    status: 'Approved', 
                    certificateId: newCert.id,
                    issueDate: newCert.date
                } : r);
                localStorage.setItem('gramuday_certificate_requests', JSON.stringify(allReq));
                
                // Refresh local list (removes from pending)
                setCertRequests(prev => prev.filter(r => r.id !== selectedRequest.id));
                
                // CLEANUP: Remove the processing state immediately so it doesn't linger
                setSelectedRequest(null); 
            }
        } catch(e) {}
    } 
    // 2. If MANUAL generation for a specific citizen
    else if (manualCertCitizenId && adminPanchayatName) {
        const citizen = registeredCitizens.find(c => c.email === manualCertCitizenId);
        if (citizen) {
             const newReq: CertificateRequest = {
                 id: `AUTO-${Date.now()}`,
                 citizenEmail: citizen.email,
                 citizenName: citizen.name,
                 panchayat: adminPanchayatName,
                 type: certType,
                 aadhaar: certAadhaar,
                 purpose: 'Issued by Administration',
                 status: 'Approved',
                 requestDate: new Date().toISOString().split('T')[0],
                 certificateId: newCert.id,
                 issueDate: newCert.date
             };
             
             try {
                const stored = localStorage.getItem('gramuday_certificate_requests');
                const allReq = stored ? JSON.parse(stored) : [];
                allReq.push(newReq);
                localStorage.setItem('gramuday_certificate_requests', JSON.stringify(allReq));
             } catch(e) {}
        }
        setManualCertCitizenId('');
    }
    
    // Clear form inputs
    setCertName('');
    setCertAadhaar('');
  };

  const handleAddScheme = () => {
      if(!newScheme.name || !newScheme.description) {
          alert("Please fill name and description");
          return;
      }

      const scheme: Scheme = {
          id: `cust-${Date.now()}`,
          name: newScheme.name,
          category: newScheme.category as any,
          description: newScheme.description,
          benefits: newScheme.benefits || '',
          eligibility: newScheme.eligibility || ''
      };

      const updated = [scheme, ...customSchemes];
      setCustomSchemes(updated);
      localStorage.setItem('gramuday_custom_schemes', JSON.stringify(updated));
      setNewScheme({ category: 'Agriculture' });
      alert("New scheme added successfully!");
  };

  const handlePrintCertificate = () => {
     if(!generatedCert) return;
     const printContent = `
        <div style="border: 10px double #4338ca; padding: 40px; text-align: center; font-family: sans-serif; position: relative; height: 90vh;">
            <div style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; opacity: 0.05; z-index: -1; display: flex; justify-content: center; items-align: center; font-size: 100px; font-weight: bold; color: gray;">OFFICIAL</div>
            <h1 style="color: #4338ca; margin-bottom: 5px; font-size: 32px; text-transform: uppercase;">${generatedCert.type}</h1>
            <p style="margin: 0; font-weight: bold; font-size: 16px; text-transform: uppercase; letter-spacing: 2px;">Government of Karnataka</p>
            <p style="margin: 5px 0 0 0; font-size: 16px; color: #555;">${adminPanchayatName || village.name}</p>
            <hr style="border: 1px solid #4338ca; width: 50%; margin: 20px auto;" />
            
            <div style="margin: 60px 40px; text-align: left; line-height: 2; font-size: 20px;">
                <p>This is to certify that <strong>${generatedCert.name}</strong>,</p>
                <p>Holder of Aadhaar Number <strong>${generatedCert.aadhaar}</strong>,</p>
                <p>Is a registered resident/applicant within the jurisdiction of this Gram Panchayat.</p>
                <p style="margin-top: 20px;">This certificate is issued for the purpose of <strong>Administrative Verification</strong>.</p>
            </div>
            
            <div style="display: flex; justify-content: space-between; margin-top: 150px; padding: 0 40px;">
                <div style="text-align: left;">
                    <p><strong>Certificate ID:</strong> ${generatedCert.id}</p>
                    <p><strong>Date of Issue:</strong> ${generatedCert.date}</p>
                </div>
                <div style="text-align: center;">
                    <div style="border: 3px solid #16a34a; color: #16a34a; display: inline-block; padding: 10px 20px; border-radius: 50%; transform: rotate(-10deg); font-weight: bold; margin-bottom: 10px; font-size: 14px;">
                        DIGITALLY SIGNED
                    </div>
                    <p style="border-top: 2px solid #000; padding-top: 10px; font-weight: bold;">Panchayat Secretary</p>
                </div>
            </div>
        </div>
     `;
     const w = window.open('', '_blank');
     if(w) {
         w.document.write('<html><head><title>Print Certificate</title></head><body style="margin: 0; padding: 20px;">');
         w.document.write(printContent);
         w.document.write('</body></html>');
         w.document.close();
         setTimeout(() => {
             w.print();
             // Auto cleanup after printing
             resetCertificateForm();
         }, 500);
     }
  };

  const renderContent = () => {
    switch(activeTab) {
      case Tab.ADMIN_OVERVIEW:
        return (
          <div className="space-y-6">
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                  { label: "Total Population", value: village.population.toLocaleString(), color: "bg-blue-50 text-blue-700" },
                  { label: "Budget Utilized", value: "65%", color: "bg-emerald-50 text-emerald-700" },
                  { label: "Pending Grievances", value: grievances.filter(g => g.status === 'Pending').length, color: "bg-red-50 text-red-700" },
                  { label: "New Applications", value: applications.filter(a => a.status === 'Pending').length, color: "bg-purple-50 text-purple-700" },
                ].map((stat, i) => (
                  <div key={i} className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex flex-col">
                    <span className="text-gray-500 text-xs font-bold uppercase tracking-wider">{stat.label}</span>
                    <span className={`text-3xl font-bold mt-2 ${stat.color.split(' ')[1]}`}>{stat.value}</span>
                    <div className={`mt-4 h-1 w-full rounded-full ${stat.color.split(' ')[0]} bg-opacity-50`}>
                      <div className={`h-full w-2/3 rounded-full ${stat.color.split(' ')[0].replace('50', '500')}`}></div>
                    </div>
                  </div>
                ))}
             </div>
             <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100">
                <h3 className="text-xl font-bold text-gray-800 mb-4">Gram Panchayat Status</h3>
                <p className="text-gray-600 mb-2">
                  Welcome to the digital governance portal for <strong>{adminPanchayatName || village.name}</strong>. 
                </p>
                <p className="text-gray-600">
                    Use the sidebar to manage citizen grievances, review scheme applications, issue official certificates, or browse the <strong>{managedVillages.length}</strong> villages under your administration.
                </p>
             </div>
          </div>
        );

      case Tab.GRIEVANCES:
        return (
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
             <div className="p-6 border-b border-gray-100">
                <h2 className="text-xl font-bold text-gray-800">Citizen Grievances</h2>
             </div>
             <div className="overflow-x-auto">
               <table className="w-full text-left">
                 <thead className="bg-gray-50 text-xs font-bold text-gray-500 uppercase">
                    <tr>
                      <th className="p-4">Date</th>
                      <th className="p-4">Subject</th>
                      <th className="p-4">Submitted By</th>
                      <th className="p-4">Status</th>
                      <th className="p-4 text-right">Action</th>
                    </tr>
                 </thead>
                 <tbody className="divide-y divide-gray-100">
                    {grievances.map(g => (
                      <tr key={g.id} className="hover:bg-gray-50">
                        <td className="p-4 text-sm text-gray-600">{g.date}</td>
                        <td className="p-4 text-gray-800 font-medium">
                           {g.subject}
                           <p className="text-xs text-gray-500 font-normal mt-1">{g.description}</p>
                        </td>
                        <td className="p-4 text-sm">{g.submittedBy}</td>
                        <td className="p-4">
                           <span className={`px-2 py-1 rounded-full text-xs font-bold ${g.status === 'Resolved' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'}`}>
                             {g.status}
                           </span>
                        </td>
                        <td className="p-4 text-right">
                           {g.status === 'Pending' && (
                             <button onClick={() => resolveGrievance(g.id)} className="bg-emerald-600 text-white px-3 py-1 rounded-lg text-xs font-bold hover:bg-emerald-700">
                               Mark Resolved
                             </button>
                           )}
                        </td>
                      </tr>
                    ))}
                 </tbody>
               </table>
             </div>
          </div>
        );

      case Tab.APPLICATIONS:
        return (
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
             <div className="p-6 border-b border-gray-100">
                <h2 className="text-xl font-bold text-gray-800">Scheme Applications</h2>
             </div>
             <div className="overflow-x-auto">
               <table className="w-full text-left">
                 <thead className="bg-gray-50 text-xs font-bold text-gray-500 uppercase">
                    <tr>
                      <th className="p-4">Date</th>
                      <th className="p-4">Scheme</th>
                      <th className="p-4">Applicant</th>
                      <th className="p-4">Status</th>
                      <th className="p-4 text-right">Action</th>
                    </tr>
                 </thead>
                 <tbody className="divide-y divide-gray-100">
                    {applications.map(a => (
                      <tr key={a.id} className="hover:bg-gray-50">
                        <td className="p-4 text-sm text-gray-600">{a.date}</td>
                        <td className="p-4 text-gray-800 font-bold">{a.schemeName}</td>
                        <td className="p-4 text-sm">{a.applicantName}</td>
                        <td className="p-4">
                           <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                              a.status === 'Approved' ? 'bg-green-100 text-green-700' : 
                              a.status === 'Rejected' ? 'bg-red-100 text-red-700' : 
                              'bg-yellow-100 text-yellow-700'
                           }`}>
                             {a.status}
                           </span>
                        </td>
                        <td className="p-4 text-right space-x-2">
                           {a.status === 'Pending' && (
                             <>
                               <button onClick={() => processApplication(a.id, 'Approved')} className="bg-emerald-600 text-white px-3 py-1 rounded-lg text-xs font-bold hover:bg-emerald-700">
                                 Approve
                               </button>
                               <button onClick={() => processApplication(a.id, 'Rejected')} className="bg-red-500 text-white px-3 py-1 rounded-lg text-xs font-bold hover:bg-red-600">
                                 Reject
                               </button>
                             </>
                           )}
                        </td>
                      </tr>
                    ))}
                 </tbody>
               </table>
             </div>
          </div>
        );

      case Tab.CITIZENS:
         return (
             <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
                <div className="p-6 border-b border-gray-100 flex justify-between items-center">
                    <div>
                        <h2 className="text-xl font-bold text-gray-800">Registered Citizens</h2>
                        <p className="text-sm text-gray-500">List of citizens linked to {adminPanchayatName}</p>
                    </div>
                    <span className="bg-indigo-100 text-indigo-800 text-xs font-bold px-3 py-1 rounded-full">{registeredCitizens.length} total</span>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="bg-gray-50 text-xs font-bold text-gray-500 uppercase">
                            <tr>
                                <th className="p-4">Name</th>
                                <th className="p-4">Mobile</th>
                                <th className="p-4">Village</th>
                                <th className="p-4">Email</th>
                                <th className="p-4 text-right">Status</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                            {registeredCitizens.map((c, idx) => (
                                <tr key={idx} className="hover:bg-gray-50 transition-colors">
                                    <td className="p-4">
                                        <div className="font-bold text-gray-800">{c.name}</div>
                                        <div className="text-xs text-gray-400">Citizen ID: #{idx + 1000}</div>
                                    </td>
                                    <td className="p-4 text-sm text-gray-600 font-medium">{c.mobile}</td>
                                    <td className="p-4 text-sm text-gray-600">
                                         {allVillages.find(v => v.id === c.villageId)?.name || 'Unknown'}
                                    </td>
                                    <td className="p-4 text-sm text-gray-600">{c.email}</td>
                                    <td className="p-4 text-right">
                                        <span className="inline-block px-2 py-0.5 rounded text-xs font-bold bg-green-100 text-green-700">Verified</span>
                                    </td>
                                </tr>
                            ))}
                            {registeredCitizens.length === 0 && (
                                <tr>
                                    <td colSpan={5} className="p-12 text-center text-gray-400">
                                        No citizens have registered under {adminPanchayatName} yet.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
             </div>
         );

      case Tab.SCHEMES:
          return (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-full">
                  <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex flex-col">
                      <h2 className="text-xl font-bold text-gray-800 mb-6">Add New Scheme</h2>
                      <div className="space-y-4 overflow-y-auto flex-1 p-1">
                          <div>
                              <label className="block text-sm font-bold text-gray-700 mb-1">Scheme Name</label>
                              <input 
                                type="text" 
                                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3" 
                                placeholder="e.g. Village Solar Initiative"
                                value={newScheme.name || ''}
                                onChange={e => setNewScheme({...newScheme, name: e.target.value})}
                              />
                          </div>
                          <div>
                              <label className="block text-sm font-bold text-gray-700 mb-1">Category</label>
                              <select 
                                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3"
                                value={newScheme.category}
                                onChange={e => setNewScheme({...newScheme, category: e.target.value as any})}
                              >
                                  <option>Agriculture</option>
                                  <option>Housing</option>
                                  <option>Health</option>
                                  <option>Education</option>
                                  <option>Financial</option>
                                  <option>Employment</option>
                              </select>
                          </div>
                          <div>
                              <label className="block text-sm font-bold text-gray-700 mb-1">Description</label>
                              <textarea 
                                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 h-20" 
                                placeholder="Brief details about the scheme..."
                                value={newScheme.description || ''}
                                onChange={e => setNewScheme({...newScheme, description: e.target.value})}
                              ></textarea>
                          </div>
                          <div>
                              <label className="block text-sm font-bold text-gray-700 mb-1">Benefits</label>
                              <input 
                                type="text" 
                                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3" 
                                placeholder="e.g. 50% Subsidy"
                                value={newScheme.benefits || ''}
                                onChange={e => setNewScheme({...newScheme, benefits: e.target.value})}
                              />
                          </div>
                          <div>
                              <label className="block text-sm font-bold text-gray-700 mb-1">Eligibility</label>
                              <input 
                                type="text" 
                                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3" 
                                placeholder="e.g. BPL Families"
                                value={newScheme.eligibility || ''}
                                onChange={e => setNewScheme({...newScheme, eligibility: e.target.value})}
                              />
                          </div>
                          <button onClick={handleAddScheme} className="w-full bg-indigo-600 text-white font-bold py-3 rounded-xl hover:bg-indigo-700">
                              Add Scheme
                          </button>
                      </div>
                  </div>

                  <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex flex-col h-full overflow-hidden">
                      <h2 className="text-xl font-bold text-gray-800 mb-4">Existing Schemes ({PANCHAYAT_SCHEMES.length + customSchemes.length})</h2>
                      <div className="flex-1 overflow-y-auto space-y-3 custom-scrollbar">
                          {customSchemes.map((s, idx) => (
                              <div key={idx} className="p-4 border border-indigo-100 bg-indigo-50 rounded-xl">
                                  <div className="flex justify-between items-start">
                                      <h3 className="font-bold text-indigo-900">{s.name}</h3>
                                      <span className="text-[10px] font-bold bg-indigo-200 text-indigo-800 px-2 py-0.5 rounded uppercase">Custom</span>
                                  </div>
                                  <p className="text-xs text-indigo-700 mt-1">{s.description}</p>
                              </div>
                          ))}
                          {PANCHAYAT_SCHEMES.map(s => (
                              <div key={s.id} className="p-4 border border-gray-100 bg-gray-50 rounded-xl opacity-75">
                                  <h3 className="font-bold text-gray-800">{s.name}</h3>
                                  <p className="text-xs text-gray-500 mt-1">{s.description}</p>
                              </div>
                          ))}
                      </div>
                  </div>
              </div>
          );

      case Tab.CERTIFICATES:
         return (
             <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 h-full">
                {/* Requests List */}
                <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex flex-col h-full overflow-hidden">
                    <h2 className="text-xl font-bold text-gray-800 mb-4">Pending Requests ({certRequests.length})</h2>
                    <div className="flex-1 overflow-y-auto space-y-3 custom-scrollbar">
                        {certRequests.length === 0 ? (
                            <div className="text-center py-12 text-gray-400">
                                No pending certificate requests.
                            </div>
                        ) : certRequests.map(req => (
                            <div key={req.id} className="p-4 border border-gray-100 rounded-xl bg-gray-50 hover:bg-white hover:shadow-md transition-all">
                                <div className="flex justify-between items-start mb-2">
                                    <div>
                                        <p className="font-bold text-gray-800">{req.citizenName}</p>
                                        <p className="text-xs text-indigo-600 font-bold uppercase">{req.type}</p>
                                    </div>
                                    <button 
                                        onClick={() => selectRequestForProcessing(req)}
                                        className="bg-indigo-600 text-white px-3 py-1 rounded-lg text-xs font-bold hover:bg-indigo-700"
                                    >
                                        Process
                                    </button>
                                </div>
                                <p className="text-sm text-gray-600 mb-1">Purpose: {req.purpose}</p>
                                <div className="flex justify-between text-xs text-gray-400">
                                    <span>Aadhaar: {req.aadhaar}</span>
                                    <span>Date: {req.requestDate}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Generator */}
                <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100 flex flex-col overflow-y-auto">
                    <h2 className="text-2xl font-bold text-gray-800 mb-6">Certificate Generator</h2>
                    
                    {!generatedCert ? (
                        <>
                            {selectedRequest && <div className="mb-4 bg-indigo-50 p-2 rounded text-xs text-indigo-800 font-bold">Processing Request ID: {selectedRequest.id}</div>}
                            
                            <div className="space-y-4 mb-8">
                               {!selectedRequest && (
                                   <div className="bg-gray-50 p-3 rounded-xl border border-gray-200">
                                       <label className="block text-sm font-bold text-gray-700 mb-1">Select Citizen (Optional)</label>
                                       <select 
                                          className="w-full bg-white border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-indigo-500"
                                          value={manualCertCitizenId}
                                          onChange={(e) => {
                                             setManualCertCitizenId(e.target.value);
                                             const c = registeredCitizens.find(u => u.email === e.target.value);
                                             if(c) {
                                                 setCertName(c.name);
                                             }
                                          }}
                                       >
                                          <option value="">-- Manual Entry (No Link) --</option>
                                          {registeredCitizens.map(c => <option key={c.email} value={c.email}>{c.name}</option>)}
                                       </select>
                                       <p className="text-[10px] text-gray-500 mt-1">Select a citizen to automatically send this certificate to their dashboard.</p>
                                   </div>
                               )}

                               <div>
                                   <label className="block text-sm font-bold text-gray-700">Certificate Type</label>
                                   <select 
                                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-indigo-500"
                                    value={certType}
                                    onChange={(e) => setCertType(e.target.value)}
                                   >
                                      <option>Birth Certificate</option>
                                      <option>Death Certificate</option>
                                      <option>Caste Certificate</option>
                                      <option>Income Certificate</option>
                                      <option>Residence Certificate</option>
                                      <option>Character Certificate</option>
                                   </select>
                               </div>
                               
                               <div>
                                   <label className="block text-sm font-bold text-gray-700">Applicant Name</label>
                                   <input 
                                    type="text" 
                                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-indigo-500" 
                                    placeholder="Full Name" 
                                    value={certName}
                                    onChange={(e) => setCertName(e.target.value)}
                                   />
                               </div>
                               
                               <div>
                                   <label className="block text-sm font-bold text-gray-700">Aadhaar Number</label>
                                   <input 
                                    type="text" 
                                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-indigo-500" 
                                    placeholder="XXXX-XXXX-XXXX" 
                                    value={certAadhaar}
                                    onChange={(e) => setCertAadhaar(e.target.value)}
                                   />
                               </div>
                               
                               <button 
                                onClick={handleGenerateCertificate}
                                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-bold py-3 rounded-xl hover:shadow-lg transition-transform active:scale-95"
                               >
                                {selectedRequest ? "Approve & Generate" : manualCertCitizenId ? "Generate & Send" : "Generate Manual Certificate"}
                               </button>
                            </div>
                        </>
                    ) : (
                        <div className="mb-8 flex flex-col items-center justify-center p-6 bg-green-50 rounded-2xl border border-green-100 animate-fade-in-down">
                             <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center text-green-600 mb-2">
                                 <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                             </div>
                             <h3 className="text-lg font-bold text-green-800">Generated Successfully</h3>
                             <p className="text-sm text-green-600">The digital record has been created.</p>
                        </div>
                    )}
                    
                    {/* Preview Area */}
                    <div className="flex-1 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200 flex flex-col items-center justify-center text-gray-400 p-8 relative overflow-hidden min-h-[200px]">
                        {generatedCert ? (
                            <div className="bg-white p-6 shadow-lg rounded-xl border border-gray-200 w-full text-left relative overflow-hidden transform scale-90 md:scale-100 transition-transform">
                                <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-100 rounded-bl-full -mr-10 -mt-10 opacity-50"></div>
                                <div className="border-b border-gray-100 pb-4 mb-4">
                                    <h3 className="text-lg font-bold text-indigo-800">{generatedCert.type}</h3>
                                    <p className="text-xs text-gray-500 font-bold uppercase tracking-wider">Govt of Karnataka</p>
                                </div>
                                <div className="space-y-2 text-sm text-gray-600 mb-6">
                                    <p><span className="font-bold text-gray-800">Name:</span> {generatedCert.name}</p>
                                    <p><span className="font-bold text-gray-800">Aadhaar:</span> {generatedCert.aadhaar}</p>
                                    <p><span className="font-bold text-gray-800">Date:</span> {generatedCert.date}</p>
                                    <p><span className="font-bold text-gray-800">ID:</span> {generatedCert.id}</p>
                                </div>
                                <div className="flex justify-between items-end">
                                    <div className="w-16 h-16 border-2 border-indigo-200 rounded-full flex items-center justify-center text-[10px] text-indigo-300 font-bold rotate-[-15deg]">
                                        SEAL
                                    </div>
                                    <div className="text-right">
                                        <div className="h-8 w-24 border-b border-gray-400 mb-1"></div>
                                        <p className="text-[10px] text-gray-400 uppercase">Signature</p>
                                    </div>
                                </div>
                            </div>
                        ) : (
                            <>
                                <svg className="w-16 h-16 mb-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                                <p>Certificate Preview</p>
                            </>
                        )}
                    </div>
                    
                    <button 
                        disabled={!generatedCert}
                        onClick={handlePrintCertificate}
                        className="mt-4 w-full bg-emerald-600 text-white font-bold py-3 rounded-xl hover:bg-emerald-700 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                    >
                        <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" /></svg>
                        Print / Download & Done
                    </button>
                    {generatedCert && (
                        <button onClick={resetCertificateForm} className="mt-3 w-full py-3 rounded-xl font-bold text-gray-500 bg-gray-100 hover:bg-gray-200">
                           Done (Close)
                        </button>
                    )}
                </div>
             </div>
         );

      case Tab.DIRECTORY:
         return (
             <VillageDirectory 
                villages={managedVillages} 
                selectedId={village.id} 
                onSelect={(v) => { onSelectVillage(v); setActiveTab(Tab.ADMIN_OVERVIEW); }} 
                language={'en'} 
                title={adminPanchayatName ? `${adminPanchayatName} Directory` : undefined}
                subtitle={adminPanchayatName ? "Manage villages under this Panchayat" : undefined}
             />
         );
      
      case Tab.BILLS:
          return (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-full">
                  <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex flex-col">
                      <h2 className="text-xl font-bold text-gray-800 mb-6">Issue Tax Bill / Invoice</h2>
                      <form onSubmit={handleIssueBill} className="space-y-4 flex-1">
                          <div>
                              <label className="block text-sm font-bold text-gray-700 mb-1">Select Citizen</label>
                              <select 
                                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3"
                                value={selectedCitizenId}
                                onChange={(e) => setSelectedCitizenId(e.target.value)}
                                required
                              >
                                  <option value="">-- Choose Citizen --</option>
                                  {registeredCitizens.map(c => (
                                      <option key={c.email} value={c.email}>{c.name} ({c.mobile})</option>
                                  ))}
                              </select>
                              {registeredCitizens.length === 0 && <p className="text-xs text-red-500 mt-1">No registered citizens in this Panchayat.</p>}
                          </div>
                          <div>
                              <label className="block text-sm font-bold text-gray-700 mb-1">Bill Type</label>
                              <select 
                                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3"
                                value={billType}
                                onChange={(e) => setBillType(e.target.value)}
                              >
                                  <option>Property Tax</option>
                                  <option>Water Tax</option>
                                  <option>Electricity</option>
                                  <option>Maintenance</option>
                                  <option>Other</option>
                              </select>
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                              <div>
                                  <label className="block text-sm font-bold text-gray-700 mb-1">Amount (₹)</label>
                                  <input 
                                    type="number" 
                                    required
                                    min="1"
                                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3" 
                                    value={billAmount}
                                    onChange={(e) => setBillAmount(e.target.value)}
                                  />
                              </div>
                              <div>
                                  <label className="block text-sm font-bold text-gray-700 mb-1">Due Date</label>
                                  <input 
                                    type="date" 
                                    required
                                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3" 
                                    value={billDueDate}
                                    onChange={(e) => setBillDueDate(e.target.value)}
                                  />
                              </div>
                          </div>
                          <div className="pt-4 mt-auto">
                              <button type="submit" className="w-full bg-indigo-600 text-white font-bold py-3 rounded-xl hover:bg-indigo-700 shadow-lg transition-transform active:scale-95">
                                  Send Bill
                              </button>
                          </div>
                      </form>
                  </div>
                  
                  <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex flex-col h-full overflow-hidden">
                      <h2 className="text-xl font-bold text-gray-800 mb-4">Issued History</h2>
                      <div className="flex-1 overflow-y-auto space-y-3 pr-2 custom-scrollbar">
                          {issuedBills.length === 0 ? (
                              <div className="text-center py-12 text-gray-400">
                                  No bills issued yet.
                              </div>
                          ) : issuedBills.map(bill => (
                              <div key={bill.id} className="p-4 border border-gray-100 rounded-xl bg-gray-50 hover:bg-white hover:shadow-sm transition-all">
                                  <div className="flex justify-between items-start mb-2">
                                      <div>
                                          <p className="font-bold text-gray-800">{bill.citizenName}</p>
                                          <p className="text-xs text-gray-500">{bill.type}</p>
                                      </div>
                                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${bill.status === 'Paid' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                          {bill.status}
                                      </span>
                                  </div>
                                  <div className="flex justify-between items-end">
                                      <p className="text-xs text-gray-400">Due: {bill.dueDate}</p>
                                      <p className="font-bold text-gray-800">₹{bill.amount}</p>
                                  </div>
                              </div>
                          ))}
                      </div>
                  </div>
              </div>
          );

      default: return null;
    }
  };

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden font-sans text-gray-900">
      {/* Admin Sidebar */}
      <aside className="w-64 bg-white border-r border-gray-200 flex flex-col hidden md:flex z-10">
        <div className="p-6 flex flex-col space-y-2">
            <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg">P</div>
                <span className="text-xl font-extrabold text-gray-800 tracking-tight">Panchayat<span className="text-indigo-600">Admin</span></span>
            </div>
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider px-1">Official Portal</span>
        </div>

        <nav className="flex-1 px-4 py-4 space-y-1">
            <button onClick={() => setActiveTab(Tab.ADMIN_OVERVIEW)} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-2xl transition-all ${activeTab === Tab.ADMIN_OVERVIEW ? 'bg-indigo-50 text-indigo-700' : 'text-gray-500 hover:bg-gray-50'}`}>
                <span className="font-semibold">Overview</span>
            </button>
            <button onClick={() => setActiveTab(Tab.GRIEVANCES)} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-2xl transition-all ${activeTab === Tab.GRIEVANCES ? 'bg-indigo-50 text-indigo-700' : 'text-gray-500 hover:bg-gray-50'}`}>
                <span className="font-semibold">Grievances</span>
                {grievances.some(g => g.status === 'Pending') && <span className="w-2 h-2 bg-red-500 rounded-full"></span>}
            </button>
            <button onClick={() => setActiveTab(Tab.APPLICATIONS)} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-2xl transition-all ${activeTab === Tab.APPLICATIONS ? 'bg-indigo-50 text-indigo-700' : 'text-gray-500 hover:bg-gray-50'}`}>
                <span className="font-semibold">Applications</span>
                {applications.some(a => a.status === 'Pending') && <span className="w-2 h-2 bg-red-500 rounded-full"></span>}
            </button>
            <button onClick={() => setActiveTab(Tab.CITIZENS)} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-2xl transition-all ${activeTab === Tab.CITIZENS ? 'bg-indigo-50 text-indigo-700' : 'text-gray-500 hover:bg-gray-50'}`}>
                <span className="font-semibold">Registered Citizens</span>
            </button>
            <button onClick={() => setActiveTab(Tab.SCHEMES)} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-2xl transition-all ${activeTab === Tab.SCHEMES ? 'bg-indigo-50 text-indigo-700' : 'text-gray-500 hover:bg-gray-50'}`}>
                <span className="font-semibold">Schemes & Welfare</span>
            </button>
            <button onClick={() => setActiveTab(Tab.BILLS)} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-2xl transition-all ${activeTab === Tab.BILLS ? 'bg-indigo-50 text-indigo-700' : 'text-gray-500 hover:bg-gray-50'}`}>
                <span className="font-semibold">Tax & Bills</span>
            </button>
            <button onClick={() => setActiveTab(Tab.CERTIFICATES)} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-2xl transition-all ${activeTab === Tab.CERTIFICATES ? 'bg-indigo-50 text-indigo-700' : 'text-gray-500 hover:bg-gray-50'}`}>
                <span className="font-semibold">Requests & Certs</span>
                {certRequests.length > 0 && <span className="w-2 h-2 bg-red-500 rounded-full"></span>}
            </button>
            <button onClick={() => setActiveTab(Tab.DIRECTORY)} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-2xl transition-all ${activeTab === Tab.DIRECTORY ? 'bg-indigo-50 text-indigo-700' : 'text-gray-500 hover:bg-gray-50'}`}>
                <span className="font-semibold">Village Directory</span>
            </button>
        </nav>
        
        <div className="p-6 border-t border-gray-100 space-y-4">
             <button onClick={onLogout} className="flex items-center text-gray-500 hover:text-red-600 transition-colors text-sm font-bold w-full px-2">
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
                Exit Portal
             </button>
             <div className="flex items-center space-x-3">
                 <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold">A</div>
                 <div>
                     <p className="text-sm font-bold text-gray-800">Admin User</p>
                     <p className="text-xs text-gray-500">Panchayat Secretary</p>
                 </div>
             </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden relative">
          <header className="bg-white border-b border-gray-200 p-4 flex justify-between items-center md:hidden">
             <span className="font-bold text-lg text-indigo-800">Panchayat Portal</span>
             <button onClick={onLogout} className="text-xs font-bold text-red-600 border border-red-200 px-3 py-1 rounded-lg">Exit</button>
          </header>
          <div className="flex-1 overflow-auto bg-gray-50 p-6">
              {renderContent()}
          </div>
      </main>
    </div>
  );
};
