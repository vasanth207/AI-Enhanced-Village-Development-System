
import React, { useState, useEffect } from 'react';
import { analyzeCropHealth, recommendCrops, predictMarketTrends } from '../services/geminiService';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { MarketData, Village, Language } from '../types';
import { translations } from '../translations';

export const Agriculture: React.FC<{ village: Village; language: Language }> = ({ village, language }) => {
  const t = translations[language].agri;
  const [activeTab, setActiveTab] = useState<'scan' | 'recommend' | 'market'>('scan');

  // Scanner State
  const [image, setImage] = useState<string | null>(null);
  const [mimeType, setMimeType] = useState<string>('');
  const [scanLoading, setScanLoading] = useState(false);
  const [scanResult, setScanResult] = useState<string>('');

  // Recommender State
  const [recParams, setRecParams] = useState({ soil: village.soilType, season: '', location: village.region });
  const [recLoading, setRecLoading] = useState(false);
  const [recResult, setRecResult] = useState('');

  // Market State
  const [cropQuery, setCropQuery] = useState('');
  const [marketLocation, setMarketLocation] = useState(village.location);
  const [marketLoading, setMarketLoading] = useState(false);
  const [marketData, setMarketData] = useState<MarketData | null>(null);

  useEffect(() => {
    setRecParams(prev => ({ ...prev, soil: village.soilType, location: village.region }));
    setMarketLocation(village.location);
  }, [village]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setMimeType(file.type);
      const reader = new FileReader();
      reader.onloadend = () => setImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const runScan = async () => {
    if (!image) return;
    setScanLoading(true);
    try {
        const base64 = image.split(',')[1];
        const res = await analyzeCropHealth(base64, mimeType, false, language);
        setScanResult(res);
    } catch (e) { setScanResult("Error analyzing image."); }
    finally { setScanLoading(false); }
  };

  const runRecommend = async () => {
      if(!recParams.soil || !recParams.season) return;
      setRecLoading(true);
      try {
          const res = await recommendCrops(recParams.soil, recParams.season, recParams.location, language);
          setRecResult(res);
      } catch (e) { setRecResult("Error generating recommendations."); }
      finally { setRecLoading(false); }
  };

  const runMarket = async () => {
      if(!cropQuery || !marketLocation) return;
      setMarketLoading(true);
      try {
          const res = await predictMarketTrends(cropQuery, marketLocation, language);
          setMarketData(res);
      } catch(e) { alert("Market analysis failed."); }
      finally { setMarketLoading(false); }
  };

  return (
    <div className="p-6 h-full flex flex-col space-y-4">
      {/* Sub Navigation */}
      <div className="flex space-x-2 bg-white p-1 rounded-xl shadow-sm border border-emerald-100 w-fit">
         {['scan', 'recommend', 'market'].map((tab) => (
             <button
                key={tab}
                onClick={() => setActiveTab(tab as any)}
                className={`px-4 py-2 rounded-lg text-sm font-bold capitalize transition-all ${
                    activeTab === tab 
                    ? 'bg-emerald-600 text-white shadow-md' 
                    : 'text-gray-500 hover:bg-gray-50'
                }`}
             >
                 {t.tabs[tab as keyof typeof t.tabs]}
             </button>
         ))}
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* SCANNER VIEW */}
        {activeTab === 'scan' && (
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6 h-full">
                <div className="bg-white rounded-3xl p-6 shadow-sm border border-emerald-50 flex flex-col">
                    <h3 className="text-xl font-bold text-emerald-900 mb-4">{t.upload}</h3>
                    <div className="flex-1 border-2 border-dashed border-emerald-200 rounded-2xl flex items-center justify-center bg-emerald-50/30 relative overflow-hidden group hover:bg-emerald-50 transition-colors">
                        {image ? <img src={image} className="max-h-64 object-contain z-10" alt="Scan" /> : (
                            <div className="text-center text-emerald-400">
                                <svg className="w-12 h-12 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                                <span>Click to upload</span>
                            </div>
                        )}
                        <input type="file" accept="image/*" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer z-20" />
                    </div>
                    <button onClick={runScan} disabled={!image || scanLoading} className="mt-4 w-full bg-emerald-600 text-white py-3 rounded-xl font-bold hover:bg-emerald-700 disabled:opacity-50 transition-colors">
                        {scanLoading ? t.analyzing : t.diagnose}
                    </button>
                </div>
                <div className="bg-white rounded-3xl p-8 shadow-sm border border-emerald-50 overflow-y-auto">
                    <h3 className="text-xl font-bold text-gray-800 mb-4">Report</h3>
                    {scanResult ? (
                        <div className="prose prose-emerald max-w-none">
                            <div className="whitespace-pre-wrap">{scanResult}</div>
                        </div>
                    ) : (
                        <div className="text-gray-400 flex flex-col items-center justify-center h-48">
                            <p>Upload an image to receive AI diagnosis</p>
                        </div>
                    )}
                </div>
             </div>
        )}

        {/* RECOMMENDER VIEW */}
        {activeTab === 'recommend' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-full">
                <div className="col-span-1 bg-gradient-to-br from-emerald-800 to-teal-900 rounded-3xl p-6 text-white shadow-xl">
                    <h3 className="text-2xl font-bold mb-6">Smart Planting</h3>
                    <div className="space-y-4">
                        <div>
                            <label className="text-emerald-200 text-xs uppercase font-bold">{t.soil}</label>
                            <input type="text" className="w-full bg-white/10 border border-emerald-500/30 rounded-lg px-3 py-2 mt-1 focus:outline-none focus:ring-2 focus:ring-emerald-400 placeholder-emerald-500/50" 
                                value={recParams.soil} onChange={e => setRecParams({...recParams, soil: e.target.value})}
                            />
                        </div>
                        <div>
                            <label className="text-emerald-200 text-xs uppercase font-bold">{t.season}</label>
                            <select className="w-full bg-white/10 border border-emerald-500/30 rounded-lg px-3 py-2 mt-1 focus:outline-none focus:ring-2 focus:ring-emerald-400 text-white"
                                value={recParams.season} onChange={e => setRecParams({...recParams, season: e.target.value})}
                            >
                                <option value="" className="text-gray-900">Select</option>
                                <option value="Spring" className="text-gray-900">Spring</option>
                                <option value="Summer" className="text-gray-900">Summer</option>
                                <option value="Monsoon" className="text-gray-900">Monsoon</option>
                                <option value="Winter" className="text-gray-900">Winter</option>
                            </select>
                        </div>
                        <div>
                            <label className="text-emerald-200 text-xs uppercase font-bold">{t.region}</label>
                            <input type="text" className="w-full bg-white/10 border border-emerald-500/30 rounded-lg px-3 py-2 mt-1 focus:outline-none focus:ring-2 focus:ring-emerald-400 placeholder-emerald-500/50"
                                value={recParams.location} onChange={e => setRecParams({...recParams, location: e.target.value})}
                            />
                        </div>
                    </div>
                    <button onClick={runRecommend} disabled={recLoading || !recParams.soil} className="mt-8 w-full bg-emerald-400 text-emerald-900 font-bold py-3 rounded-xl hover:bg-emerald-300 transition-colors flex items-center justify-center">
                        {recLoading ? (
                             <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                        ) : t.getRec}
                    </button>
                </div>
                <div className="col-span-1 md:col-span-2 bg-white rounded-3xl p-8 shadow-sm border border-emerald-50 overflow-y-auto relative">
                     {recResult ? (
                         <div className="prose prose-emerald">
                             <div className="whitespace-pre-wrap">{recResult}</div>
                         </div>
                     ) : (
                        <div className="h-full flex flex-col items-center justify-center text-gray-400">
                             <p>Enter soil details to get AI crop advice</p>
                        </div>
                     )}
                </div>
            </div>
        )}

        {/* MARKET PREDICTOR VIEW */}
        {activeTab === 'market' && (
            <div className="flex flex-col h-full space-y-6">
                <div className="flex flex-col md:flex-row gap-4 items-start md:items-center bg-white p-4 rounded-2xl shadow-sm border border-emerald-50">
                    <input type="text" placeholder={t.cropName} className="w-full md:w-1/3 bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all" 
                       value={cropQuery} onChange={e => setCropQuery(e.target.value)}
                    />
                    <input type="text" placeholder={t.location} className="w-full md:w-1/3 bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all" 
                       value={marketLocation} onChange={e => setMarketLocation(e.target.value)}
                    />
                    <button onClick={runMarket} disabled={marketLoading || !cropQuery || !marketLocation} className="w-full md:w-auto flex-1 bg-emerald-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-emerald-700 shadow-md transition-all disabled:opacity-50">
                        {marketLoading ? t.analyzing : t.predict}
                    </button>
                </div>

                {marketData ? (
                    <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-6 min-h-0">
                        <div className="lg:col-span-2 bg-white rounded-3xl p-6 shadow-sm border border-emerald-50 flex flex-col">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <h3 className="text-2xl font-bold text-gray-800 capitalize">{marketData.crop} Forecast</h3>
                                </div>
                                <div className="text-right">
                                    <p className="text-3xl font-bold text-emerald-600">{marketData.currentPrice}</p>
                                </div>
                            </div>
                            <div className="flex-1 min-h-[300px]">
                                <ResponsiveContainer width="100%" height="100%">
                                    <AreaChart data={marketData.forecast}>
                                        <defs>
                                            <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                                                <stop offset="5%" stopColor="#059669" stopOpacity={0.8}/>
                                                <stop offset="95%" stopColor="#059669" stopOpacity={0}/>
                                            </linearGradient>
                                        </defs>
                                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0fdf4" />
                                        <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill: '#6b7280'}} />
                                        <YAxis axisLine={false} tickLine={false} tick={{fill: '#6b7280'}} domain={['auto', 'auto']} />
                                        <Tooltip contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'}} />
                                        <Area type="monotone" dataKey="price" stroke="#059669" strokeWidth={3} fillOpacity={1} fill="url(#colorPrice)" />
                                    </AreaChart>
                                </ResponsiveContainer>
                            </div>
                        </div>
                        <div className="bg-emerald-50 rounded-3xl p-6 border border-emerald-100 flex flex-col overflow-y-auto">
                            <h4 className="font-bold text-emerald-900 mb-4">Market Intelligence</h4>
                            <p className="text-sm text-emerald-800 mb-6 leading-relaxed">{marketData.analysis}</p>
                        </div>
                    </div>
                ) : (
                    <div className="flex-1 bg-gray-50 rounded-3xl border-2 border-dashed border-gray-200 flex flex-col items-center justify-center text-gray-400">
                        <p className="text-lg">Enter crop and location to view real-time market insights</p>
                    </div>
                )}
            </div>
        )}
      </div>
    </div>
  );
};
