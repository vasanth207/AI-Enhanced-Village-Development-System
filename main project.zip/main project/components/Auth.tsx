
import React, { useState, useEffect } from 'react';
import { User, UserRole, Village } from '../types';

interface AuthProps {
  onLogin: (user: User) => void;
  initialRole?: UserRole;
  onBack: () => void;
  villages?: Village[];
}

export const Auth: React.FC<AuthProps> = ({ onLogin, initialRole = 'citizen', onBack, villages = [] }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  
  // Form State
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [role, setRole] = useState<UserRole>(initialRole);
  const [villageId, setVillageId] = useState('');
  const [panchayatName, setPanchayatName] = useState('');

  // Extract unique panchayats for autocomplete
  const uniquePanchayats = React.useMemo(() => {
    const names = villages.map(v => v.panchayat).filter(Boolean);
    return Array.from(new Set(names)).sort();
  }, [villages]);

  // Derived panchayat for citizen display
  const currentVillagePanchayat = role === 'citizen' ? villages.find(v => v.id === villageId)?.panchayat : null;

  useEffect(() => {
    setRole(initialRole);
  }, [initialRole]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    setSuccessMsg('');

    // Simulate Network Delay
    setTimeout(() => {
      try {
        const storedUsersStr = localStorage.getItem('gramuday_users');
        const users = storedUsersStr ? JSON.parse(storedUsersStr) : [];

        if (isLogin) {
          // --- LOGIN LOGIC ---
          const user = users.find((u: any) => u.email.toLowerCase() === email.toLowerCase());
          
          if (!user) {
            throw new Error("Account not found. Please register first.");
          }
          
          if (user.password !== password) {
            throw new Error("Incorrect password.");
          }

          // Force role check if strictly logging into specific portal (optional, but good UX)
          // For now we allow crossover login but it might redirect
          
          // Login Successful
          onLogin(user);
        } else {
          // --- REGISTER LOGIC ---
          const existingUser = users.find((u: any) => u.email.toLowerCase() === email.toLowerCase());
          
          if (existingUser) {
            throw new Error("This email is already registered. Please sign in.");
          }

          if (role === 'citizen' && !villageId) {
             throw new Error("Please select your village.");
          }

          if (role === 'official' && !panchayatName) {
            throw new Error("Please enter your Gram Panchayat name.");
          }

          // Determine Panchayat Name based on role
          let finalPanchayatName: string | undefined = undefined;
          if (role === 'official') {
              finalPanchayatName = panchayatName.trim();
          } else if (role === 'citizen') {
              // Automatically link citizen to the panchayat of their village
              const selectedV = villages.find(v => v.id === villageId);
              if (selectedV) {
                  finalPanchayatName = selectedV.panchayat;
              }
          }

          const newUser: User & { password: string } = { 
              name, 
              email, 
              mobile, 
              role, 
              password,
              villageId: role === 'citizen' ? villageId : undefined,
              panchayatName: finalPanchayatName
          };
          users.push(newUser);
          localStorage.setItem('gramuday_users', JSON.stringify(users));

          setSuccessMsg("Account created successfully! Please sign in.");
          setIsLogin(true); // Switch to login view
          // Reset sensitive fields but keep email for convenience
          setPassword('');
          setName('');
          setMobile('');
          setVillageId('');
          setPanchayatName('');
        }
      } catch (err: any) {
        setError(err.message || "An error occurred.");
      } finally {
        setIsLoading(false);
      }
    }, 1000);
  };

  const toggleMode = () => {
    setIsLogin(!isLogin);
    setError('');
    setSuccessMsg('');
    setEmail('');
    setPassword('');
    setName('');
    setMobile('');
    setVillageId('');
    setPanchayatName('');
    // Keep the initial role when toggling
  };

  const isOfficial = role === 'official';
  const themeColor = isOfficial ? 'indigo' : 'emerald';

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4 relative overflow-hidden font-sans">
      {/* Background Decor */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0 pointer-events-none">
        <div className={`absolute -top-24 -left-24 w-96 h-96 ${isOfficial ? 'bg-indigo-400' : 'bg-emerald-400'} rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob`}></div>
        <div className={`absolute top-0 -right-4 w-96 h-96 ${isOfficial ? 'bg-purple-400' : 'bg-teal-400'} rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000`}></div>
        <div className={`absolute -bottom-32 left-20 w-96 h-96 ${isOfficial ? 'bg-blue-400' : 'bg-cyan-400'} rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-4000`}></div>
      </div>

      {/* Content Card */}
      <div className="max-w-md w-full bg-white rounded-3xl shadow-2xl overflow-hidden z-50 relative border border-gray-100">
        
        {/* Header with Back Button */}
        <div className="p-4 border-b border-gray-100 flex items-center">
            <button 
                onClick={onBack}
                className="flex items-center text-gray-500 hover:text-gray-800 transition-colors text-sm font-bold px-2 py-1 rounded-lg hover:bg-gray-100"
            >
                <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
                Back to Home
            </button>
        </div>

        <div className="p-8 pt-6 md:p-10 md:pt-6">
          <div className="flex justify-center mb-6">
             {isOfficial ? (
                <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-bold text-2xl shadow-lg">P</div>
                    <span className="text-2xl font-extrabold text-gray-800 tracking-tight">Panchayat<span className="text-indigo-600">Admin</span></span>
                </div>
             ) : (
                <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center text-white font-bold text-2xl shadow-lg">G</div>
                    <span className="text-2xl font-extrabold text-gray-800 tracking-tight">Gram<span className="text-emerald-600">Uday</span></span>
                </div>
             )}
          </div>

          <h2 className="text-2xl font-bold text-center text-gray-800 mb-2">
            {isLogin ? 'Welcome Back' : `Join ${isOfficial ? 'Panchayat Portal' : 'GramUday'}`}
          </h2>
          <p className="text-center text-gray-500 mb-6 text-sm">
             Accessing as: <span className={`font-bold uppercase ${isOfficial ? 'text-indigo-600' : 'text-emerald-600'}`}>{role}</span>
          </p>

          {/* Error / Success Messages */}
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-100 rounded-xl flex items-center text-red-700 text-sm font-medium animate-pulse">
              <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              {error}
            </div>
          )}
          {successMsg && (
            <div className={`mb-6 p-4 rounded-xl flex items-center text-sm font-medium ${isOfficial ? 'bg-indigo-50 border-indigo-100 text-indigo-700' : 'bg-emerald-50 border-emerald-100 text-emerald-700'}`}>
               <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
               {successMsg}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <>
                <div className="grid grid-cols-2 gap-3 mb-2 p-1 bg-gray-100 rounded-xl">
                    <button
                        type="button"
                        onClick={() => setRole('citizen')}
                        className={`p-2 rounded-lg font-bold text-xs transition-all ${role === 'citizen' ? 'bg-white shadow text-gray-800' : 'text-gray-500'}`}
                    >
                        Citizen
                    </button>
                    <button
                        type="button"
                        onClick={() => setRole('official')}
                        className={`p-2 rounded-lg font-bold text-xs transition-all ${role === 'official' ? 'bg-white shadow text-gray-800' : 'text-gray-500'}`}
                    >
                        Official
                    </button>
                 </div>
              
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1 ml-1 uppercase">Full Name</label>
                  <input 
                    type="text" 
                    required
                    className={`w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-${themeColor}-500 transition-all`}
                    placeholder="Full Name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1 ml-1 uppercase">Mobile Number</label>
                  <input 
                    type="tel" 
                    required
                    pattern="[0-9]{10}"
                    className={`w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-${themeColor}-500 transition-all`}
                    placeholder="9876543210"
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value)}
                  />
                </div>

                {role === 'citizen' && (
                    <div>
                        <label className="block text-xs font-bold text-gray-700 mb-1 ml-1 uppercase">Select Village</label>
                        <select
                            required
                            className={`w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 text-gray-900 focus:outline-none focus:ring-2 focus:ring-${themeColor}-500 transition-all`}
                            value={villageId}
                            onChange={(e) => setVillageId(e.target.value)}
                        >
                            <option value="">Select your village</option>
                            {villages.map(v => (
                                <option key={v.id} value={v.id}>{v.name} ({v.location})</option>
                            ))}
                        </select>
                        {/* Show Linked Panchayat automatically */}
                        {currentVillagePanchayat && (
                           <div className="mt-3 p-3 bg-emerald-50 border border-emerald-100 rounded-xl flex items-center justify-between animate-fade-in-down">
                              <div>
                                 <p className="text-[10px] text-emerald-500 font-bold uppercase tracking-wider">Linked Panchayat</p>
                                 <p className="text-emerald-900 font-bold text-sm">{currentVillagePanchayat}</p>
                              </div>
                              <div className="h-8 w-8 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600">
                                 <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
                              </div>
                           </div>
                        )}
                    </div>
                )}
                
                {role === 'official' && (
                    <div>
                        <label className="block text-xs font-bold text-gray-700 mb-1 ml-1 uppercase">Gram Panchayat Name</label>
                        <input 
                            type="text" 
                            required
                            list="panchayat-options"
                            className={`w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-${themeColor}-500 transition-all`}
                            placeholder="Type to search Panchayat..."
                            value={panchayatName}
                            onChange={(e) => setPanchayatName(e.target.value)}
                        />
                         <datalist id="panchayat-options">
                            {uniquePanchayats.map(p => <option key={p} value={p} />)}
                         </datalist>
                         <p className="text-[10px] text-gray-500 mt-1 ml-1">Select from list or type exact Panchayat name.</p>
                    </div>
                )}
              </>
            )}
            
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1 ml-1 uppercase">Email Address</label>
              <input 
                type="email" 
                required
                className={`w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-${themeColor}-500 transition-all`}
                placeholder={isOfficial ? "admin.panchayat@gov.in" : "citizen@example.com"}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1 ml-1 uppercase">Password</label>
              <input 
                type="password" 
                required
                minLength={6}
                className={`w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-${themeColor}-500 transition-all`}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            <button 
              type="submit" 
              disabled={isLoading}
              className={`w-full bg-gradient-to-r ${isOfficial ? 'from-indigo-600 to-purple-600' : 'from-emerald-600 to-teal-600'} text-white font-bold py-3.5 rounded-xl shadow-lg hover:shadow-xl hover:scale-[1.02] transition-all duration-200 disabled:opacity-70 disabled:scale-100 flex items-center justify-center`}
            >
              {isLoading ? (
                <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              ) : (
                isLogin ? 'Sign In' : 'Create Account'
              )}
            </button>

            <div className="text-center mt-6">
              <p className="text-sm text-gray-500">
                {isLogin ? "Don't have an account?" : "Already have an account?"}
                <button 
                  type="button"
                  onClick={toggleMode}
                  className={`ml-2 font-bold ${isOfficial ? 'text-indigo-600 hover:text-indigo-700' : 'text-emerald-600 hover:text-emerald-700'} hover:underline`}
                >
                  {isLogin ? 'Sign Up' : 'Sign In'}
                </button>
              </p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};