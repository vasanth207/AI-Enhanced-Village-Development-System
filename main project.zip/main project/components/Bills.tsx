
import React, { useState, useEffect } from 'react';
import { User, Language, Bill } from '../types';
import { translations } from '../translations';

export const Bills: React.FC<{ user: User, language: Language }> = ({ user, language }) => {
  const [bills, setBills] = useState<Bill[]>([]);
  const [activeTab, setActiveTab] = useState<'PENDING' | 'HISTORY'>('PENDING');
  
  // Payment Modal State
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [currentBill, setCurrentBill] = useState<Bill | null>(null);
  const [paymentStep, setPaymentStep] = useState<'SCAN' | 'SUCCESS'>('SCAN');
  
  const t = translations[language].bills;

  useEffect(() => {
    // Load bills from local storage
    try {
        const storedBills = localStorage.getItem('gramuday_bills');
        if (storedBills) {
            const allBills = JSON.parse(storedBills) as Bill[];
            // Filter bills for current user
            const myBills = allBills.filter(b => b.citizenEmail.toLowerCase() === user.email.toLowerCase());
            setBills(myBills);
        }
    } catch (e) {
        console.error("Failed to load bills", e);
    }
  }, [user.email]);

  const initiatePayment = (bill: Bill) => {
      setCurrentBill(bill);
      setPaymentStep('SCAN');
      setPaymentModalOpen(true);
  };

  const handleConfirmPayment = () => {
      setPaymentStep('SUCCESS');
      
      // Auto-close after showing success message for a moment
      setTimeout(() => {
          finalizePayment();
      }, 2500);
  };

  const finalizePayment = () => {
      if (!currentBill) return;

      const updatedBills = bills.map(b => {
          if (b.id === currentBill.id) {
              return {
                  ...b,
                  status: 'Paid' as const,
                  paidDate: new Date().toISOString().split('T')[0],
                  transactionId: `TXN${Math.floor(Math.random() * 1000000)}`
              };
          }
          return b;
      });

      setBills(updatedBills);

      // Update Local Storage globally
      try {
          const storedBills = localStorage.getItem('gramuday_bills');
          if (storedBills) {
              const allBills = JSON.parse(storedBills) as Bill[];
              const newGlobalBills = allBills.map(b => b.id === currentBill.id ? updatedBills.find(ub => ub.id === currentBill.id)! : b);
              localStorage.setItem('gramuday_bills', JSON.stringify(newGlobalBills));
          }
      } catch(e) {}
      
      setPaymentModalOpen(false);
      setCurrentBill(null);
  };

  const pendingBills = bills.filter(b => b.status === 'Pending');
  const historyBills = bills.filter(b => b.status === 'Paid');

  return (
    <div className="p-6 h-full flex flex-col space-y-6 relative">
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-emerald-50">
            <h1 className="text-3xl font-bold text-gray-800">{t.title}</h1>
            <p className="text-gray-500">{t.subtitle}</p>
        </div>

        <div className="flex space-x-2 bg-white p-1 rounded-xl shadow-sm border border-emerald-100 w-fit">
             <button
                onClick={() => setActiveTab('PENDING')}
                className={`px-6 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'PENDING' ? 'bg-red-500 text-white shadow-md' : 'text-gray-500 hover:bg-red-50'}`}
             >
                 {t.pending} ({pendingBills.length})
             </button>
             <button
                onClick={() => setActiveTab('HISTORY')}
                className={`px-6 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'HISTORY' ? 'bg-emerald-500 text-white shadow-md' : 'text-gray-500 hover:bg-emerald-50'}`}
             >
                 {t.history}
             </button>
        </div>

        <div className="flex-1 overflow-y-auto">
            {activeTab === 'PENDING' && (
                <div className="space-y-4">
                    {pendingBills.length > 0 ? pendingBills.map(bill => (
                        <div key={bill.id} className="bg-white border-l-4 border-red-500 rounded-xl p-6 shadow-sm flex flex-col md:flex-row justify-between items-center hover:shadow-md transition-shadow">
                            <div className="mb-4 md:mb-0">
                                <div className="flex items-center space-x-2 mb-1">
                                    <span className="text-xs font-bold bg-gray-100 text-gray-600 px-2 py-1 rounded uppercase tracking-wider">{bill.type}</span>
                                    <span className="text-xs text-gray-400">ID: {bill.id}</span>
                                </div>
                                <h3 className="text-xl font-bold text-gray-800">{bill.panchayat}</h3>
                                <p className="text-sm text-gray-500">Issued: {bill.issuedDate} • <span className="text-red-600 font-bold">Due: {bill.dueDate}</span></p>
                            </div>
                            <div className="flex items-center gap-6">
                                <div className="text-right">
                                    <p className="text-xs text-gray-400 uppercase font-bold">Amount Due</p>
                                    <p className="text-2xl font-black text-gray-800">₹{bill.amount.toLocaleString()}</p>
                                </div>
                                <button 
                                    onClick={() => initiatePayment(bill)}
                                    className="bg-red-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-red-700 shadow-lg transform active:scale-95 transition-all"
                                >
                                    {t.payNow}
                                </button>
                            </div>
                        </div>
                    )) : (
                        <div className="flex flex-col items-center justify-center py-12 text-gray-400">
                            <svg className="w-16 h-16 mb-4 text-emerald-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                            <p className="text-lg font-medium">{t.noPending}</p>
                        </div>
                    )}
                </div>
            )}

            {activeTab === 'HISTORY' && (
                <div className="space-y-4">
                    {historyBills.length > 0 ? historyBills.map(bill => (
                        <div key={bill.id} className="bg-white border-l-4 border-emerald-500 rounded-xl p-6 shadow-sm flex flex-col md:flex-row justify-between items-center opacity-75 hover:opacity-100 transition-opacity">
                            <div className="mb-4 md:mb-0">
                                <div className="flex items-center space-x-2 mb-1">
                                    <span className="text-xs font-bold bg-gray-100 text-gray-600 px-2 py-1 rounded uppercase tracking-wider">{bill.type}</span>
                                    <span className="text-xs text-emerald-600 font-bold">PAID</span>
                                </div>
                                <h3 className="text-lg font-bold text-gray-800">{bill.panchayat}</h3>
                                <p className="text-sm text-gray-500">Paid on: {bill.paidDate} • Txn: {bill.transactionId}</p>
                            </div>
                            <div className="flex items-center gap-6">
                                <div className="text-right">
                                    <p className="text-xs text-gray-400 uppercase font-bold">Amount Paid</p>
                                    <p className="text-xl font-bold text-gray-600">₹{bill.amount.toLocaleString()}</p>
                                </div>
                                <button className="text-emerald-600 hover:text-emerald-700 text-sm font-bold flex items-center">
                                    <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                                    {t.download}
                                </button>
                            </div>
                        </div>
                    )) : (
                        <div className="text-center py-12 text-gray-400">
                            <p>No payment history available.</p>
                        </div>
                    )}
                </div>
            )}
        </div>

        {/* Payment Modal */}
        {paymentModalOpen && currentBill && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
                <div className="bg-white rounded-3xl p-8 max-w-sm w-full shadow-2xl flex flex-col items-center animate-fade-in-down border border-gray-100">
                    
                    {paymentStep === 'SCAN' ? (
                        <>
                            <div className="w-full flex justify-between items-center mb-4">
                                <h3 className="text-xl font-bold text-gray-800">Scan to Pay</h3>
                                <button onClick={() => setPaymentModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                                </button>
                            </div>
                            
                            <p className="text-sm text-gray-500 mb-6 text-center">Use any UPI app to scan and pay safely</p>
                            
                            <div className="bg-white p-4 rounded-2xl border-2 border-dashed border-gray-200 mb-6 shadow-inner relative group cursor-pointer" onClick={() => {}}>
                                <img 
                                    src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=upi://pay?pa=gramuday@upi&pn=${encodeURIComponent(currentBill.panchayat)}&am=${currentBill.amount}&cu=INR`} 
                                    alt="Payment QR" 
                                    className="w-48 h-48 mix-blend-multiply"
                                />
                            </div>
                            
                            <div className="text-center mb-8">
                                <p className="text-xs text-gray-400 uppercase font-bold tracking-widest">Total Amount</p>
                                <p className="text-4xl font-black text-gray-800 mt-1">₹{currentBill.amount.toLocaleString()}</p>
                            </div>

                            <div className="flex gap-3 w-full">
                                <button 
                                    onClick={() => setPaymentModalOpen(false)}
                                    className="flex-1 py-3.5 rounded-xl font-bold text-gray-500 bg-gray-100 hover:bg-gray-200 transition-colors"
                                >
                                    Cancel
                                </button>
                                <button 
                                    onClick={handleConfirmPayment}
                                    className="flex-1 py-3.5 rounded-xl font-bold bg-emerald-600 text-white hover:bg-emerald-700 shadow-lg hover:shadow-xl transition-all flex items-center justify-center"
                                >
                                    <span className="mr-2">Click OK</span>
                                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                                </button>
                            </div>
                        </>
                    ) : (
                        <div className="flex flex-col items-center justify-center py-8 animate-fade-in-up">
                            <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mb-6">
                                <svg className="w-12 h-12 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                            </div>
                            <h3 className="text-2xl font-black text-gray-800 mb-2">Payment Successful!</h3>
                            <p className="text-gray-500 text-center mb-6">Your transaction has been processed securely.</p>
                            <div className="w-full bg-gray-50 rounded-xl p-4 mb-4 border border-gray-100">
                                <div className="flex justify-between text-sm mb-2">
                                    <span className="text-gray-500">Amount Paid</span>
                                    <span className="font-bold text-gray-800">₹{currentBill.amount.toLocaleString()}</span>
                                </div>
                                <div className="flex justify-between text-sm">
                                    <span className="text-gray-500">Ref ID</span>
                                    <span className="font-mono text-gray-800">TXN{Math.floor(Math.random() * 1000000)}</span>
                                </div>
                            </div>
                            <p className="text-xs text-gray-400">Closing automatically...</p>
                        </div>
                    )}
                </div>
            </div>
        )}
    </div>
  );
};
