import React, { useState, useEffect } from 'react';
import { User, Language, CertificateRequest } from '../types';
import { translations } from '../translations';

export const Certificates: React.FC<{ user: User, language: Language }> = ({ user, language }) => {
  const [requests, setRequests] = useState<CertificateRequest[]>([]);
  const [activeTab, setActiveTab] = useState<'NEW' | 'HISTORY'>('NEW');
  
  // Form State
  const [type, setType] = useState('Income Certificate');
  const [aadhaar, setAadhaar] = useState('');
  const [purpose, setPurpose] = useState('');
  const [loading, setLoading] = useState(false);

  const t = translations[language].certificates;

  useEffect(() => {
    // Function to load data
    const loadRequests = () => {
        try {
            const stored = localStorage.getItem('gramuday_certificate_requests');
            if (stored) {
                const allRequests = JSON.parse(stored) as CertificateRequest[];
                const myRequests = allRequests.filter(r => r.citizenEmail.toLowerCase() === user.email.toLowerCase());
                // Simple equality check to avoid re-renders if no change is hard with objects, 
                // but React state updates batching handles it reasonably well.
                // We sort to show newest first.
                setRequests(myRequests.sort((a, b) => new Date(b.requestDate).getTime() - new Date(a.requestDate).getTime()));
            }
        } catch (e) {
            console.error("Failed to load requests", e);
        }
    };

    loadRequests();
    
    // Polling every 3 seconds to auto-update when admin approves
    const interval = setInterval(loadRequests, 3000);

    return () => clearInterval(interval);
  }, [user.email, activeTab]);

  const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (!aadhaar || !purpose || !user.panchayatName) {
          alert("Please fill all details. Ensure you are linked to a Panchayat.");
          return;
      }
      setLoading(true);

      const newRequest: CertificateRequest = {
          id: `REQ-${Date.now()}`,
          citizenEmail: user.email,
          citizenName: user.name,
          panchayat: user.panchayatName,
          type,
          aadhaar,
          purpose,
          status: 'Pending',
          requestDate: new Date().toISOString().split('T')[0]
      };

      try {
          const stored = localStorage.getItem('gramuday_certificate_requests');
          const allRequests = stored ? JSON.parse(stored) : [];
          allRequests.push(newRequest);
          localStorage.setItem('gramuday_certificate_requests', JSON.stringify(allRequests));
          
          setTimeout(() => {
              setRequests(prev => [newRequest, ...prev]);
              setActiveTab('HISTORY');
              setAadhaar('');
              setPurpose('');
              setLoading(false);
          }, 800);
      } catch (e) {
          setLoading(false);
          alert("Failed to submit request");
      }
  };

  const handleDownload = (req: CertificateRequest) => {
      const printContent = `
        <div style="border: 10px double #4338ca; padding: 40px; text-align: center; font-family: sans-serif; position: relative; height: 90vh;">
            <div style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; opacity: 0.05; z-index: -1; display: flex; justify-content: center; items-align: center; font-size: 100px; font-weight: bold; color: gray;">OFFICIAL</div>
            <h1 style="color: #4338ca; margin-bottom: 5px; font-size: 32px; text-transform: uppercase;">${req.type}</h1>
            <p style="margin: 0; font-weight: bold; font-size: 16px; text-transform: uppercase; letter-spacing: 2px;">Government of Karnataka</p>
            <p style="margin: 5px 0 0 0; font-size: 16px; color: #555;">${req.panchayat}</p>
            <hr style="border: 1px solid #4338ca; width: 50%; margin: 20px auto;" />
            
            <div style="margin: 60px 40px; text-align: left; line-height: 2; font-size: 20px;">
                <p>This is to certify that <strong>${req.citizenName}</strong>,</p>
                <p>Holder of Aadhaar Number <strong>${req.aadhaar}</strong>,</p>
                <p>Is a registered resident/applicant within the jurisdiction of this Gram Panchayat.</p>
                <p style="margin-top: 20px;">This certificate is issued for the purpose of: <strong>${req.purpose}</strong>.</p>
            </div>
            
            <div style="display: flex; justify-content: space-between; margin-top: 150px; padding: 0 40px;">
                <div style="text-align: left;">
                    <p><strong>Certificate ID:</strong> ${req.certificateId}</p>
                    <p><strong>Date of Issue:</strong> ${req.issueDate}</p>
                </div>
                <div style="text-align: center;">
                    <div style="border: 3px solid #16a34a; color: #16a34a; display: inline-block; padding: 10px 20px; border-radius: 50%; transform: rotate(-10deg); font-weight: bold; margin-bottom: 10px; font-size: 14px;">
                        DIGITALLY SIGNED
                    </div>
                    <p style="border-top: 2px solid #000; padding-top: 10px; font-weight: bold;">Panchayat Secretary</p>
                </div>
            </div>
        </div>
     `;
     const w = window.open('', '_blank');
     if(w) {
         w.document.write('<html><head><title>Print Certificate</title></head><body style="margin: 0; padding: 20px;">');
         w.document.write(printContent);
         w.document.write('</body></html>');
         w.document.close();
         setTimeout(() => w.print(), 500);
     }
  };

  return (
    <div className="p-6 h-full flex flex-col space-y-6 relative">
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-purple-50">
            <h1 className="text-3xl font-bold text-gray-800">{t.title}</h1>
            <p className="text-gray-500">{t.subtitle} • {user.panchayatName || 'Panchayat Not Linked'}</p>
        </div>

        <div className="flex space-x-2 bg-white p-1 rounded-xl shadow-sm border border-purple-100 w-fit">
             <button
                onClick={() => setActiveTab('NEW')}
                className={`px-6 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'NEW' ? 'bg-purple-600 text-white shadow-md' : 'text-gray-500 hover:bg-purple-50'}`}
             >
                 {t.newRequest}
             </button>
             <button
                onClick={() => setActiveTab('HISTORY')}
                className={`px-6 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'HISTORY' ? 'bg-indigo-600 text-white shadow-md' : 'text-gray-500 hover:bg-indigo-50'}`}
             >
                 {t.history}
             </button>
        </div>

        <div className="flex-1 overflow-y-auto">
            {activeTab === 'NEW' && (
                <div className="bg-white rounded-3xl p-8 shadow-sm border border-purple-50 max-w-2xl">
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div>
                            <label className="block text-sm font-bold text-gray-700 mb-2">{t.type}</label>
                            <select 
                                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                                value={type}
                                onChange={e => setType(e.target.value)}
                            >
                                <option>Income Certificate</option>
                                <option>Caste Certificate</option>
                                <option>Birth Certificate</option>
                                <option>Residence Certificate</option>
                                <option>Character Certificate</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-gray-700 mb-2">{t.aadhaar}</label>
                            <input 
                                type="text"
                                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                                placeholder="XXXX-XXXX-XXXX"
                                value={aadhaar}
                                onChange={e => setAadhaar(e.target.value)}
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-gray-700 mb-2">{t.purpose}</label>
                            <textarea 
                                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500 h-32 resize-none"
                                placeholder="Reason for request..."
                                value={purpose}
                                onChange={e => setPurpose(e.target.value)}
                            ></textarea>
                        </div>
                        <button 
                            type="submit" 
                            disabled={loading || !user.panchayatName}
                            className="w-full bg-purple-600 text-white font-bold py-4 rounded-xl hover:bg-purple-700 shadow-lg transition-transform active:scale-95 disabled:opacity-50"
                        >
                            {loading ? 'Submitting...' : t.submit}
                        </button>
                        {!user.panchayatName && (
                            <p className="text-xs text-red-500 text-center">Your account is not linked to a Panchayat. Please contact admin.</p>
                        )}
                    </form>
                </div>
            )}

            {activeTab === 'HISTORY' && (
                <div className="space-y-4">
                    {requests.length > 0 ? requests.map(req => (
                        <div key={req.id} className="bg-white border border-gray-100 rounded-xl p-6 shadow-sm flex flex-col md:flex-row justify-between items-center hover:shadow-md transition-all">
                            <div className="mb-4 md:mb-0">
                                <div className="flex items-center space-x-2 mb-2">
                                    <h3 className="text-lg font-bold text-gray-800">{req.type}</h3>
                                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                                        req.status === 'Approved' ? 'bg-green-100 text-green-700' :
                                        req.status === 'Rejected' ? 'bg-red-100 text-red-700' :
                                        'bg-yellow-100 text-yellow-700'
                                    }`}>
                                        {req.status}
                                    </span>
                                </div>
                                <p className="text-sm text-gray-500">Req Date: {req.requestDate} • ID: {req.id}</p>
                                <p className="text-sm text-gray-600 mt-1 italic">"{req.purpose}"</p>
                            </div>
                            
                            {req.status === 'Approved' && (
                                <button 
                                    onClick={() => handleDownload(req)}
                                    className="flex items-center space-x-2 bg-indigo-50 text-indigo-700 px-6 py-3 rounded-xl font-bold hover:bg-indigo-100 transition-colors"
                                >
                                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                                    <span>{t.download}</span>
                                </button>
                            )}
                            {req.status === 'Rejected' && (
                                <div className="text-red-500 text-sm font-bold px-4">Request Rejected</div>
                            )}
                            {req.status === 'Pending' && (
                                <div className="text-yellow-600 text-sm font-bold px-4">Processing</div>
                            )}
                        </div>
                    )) : (
                        <div className="flex flex-col items-center justify-center py-12 text-gray-400">
                             <p>No certificate requests found.</p>
                        </div>
                    )}
                </div>
            )}
        </div>
    </div>
  );
};