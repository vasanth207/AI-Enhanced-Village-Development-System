
import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from 'recharts';
import { Village, Language } from '../types';
import { translations } from '../translations';

const waterData = [
  { name: 'Mon', usage: 4000 },
  { name: 'Tue', usage: 3000 },
  { name: 'Wed', usage: 2000 },
  { name: 'Thu', usage: 2780 },
  { name: 'Fri', usage: 1890 },
  { name: 'Sat', usage: 2390 },
  { name: 'Sun', usage: 3490 },
];

const cropData = [
    { name: 'Wheat', price: 120 },
    { name: 'Corn', price: 98 },
    { name: 'Rice', price: 150 },
    { name: 'Soy', price: 86 },
];

export const Dashboard: React.FC<{ village: Village; language: Language }> = ({ village, language }) => {
  const t = translations[language].dashboard;

  return (
    <div className="p-6 h-full overflow-y-auto">
       <div className="mb-6">
            <h1 className="text-3xl font-bold text-gray-800">{village.name} {t.title}</h1>
            <p className="text-gray-500">{village.location} • {village.soilType} Soil Region</p>
       </div>

       {/* Header Stats */}
       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {[
            { label: t.population, value: village.population.toLocaleString(), change: "+2%", color: "text-blue-600", bg: "bg-blue-50" },
            { label: t.waterReserves, value: "72%", change: "-5%", color: "text-cyan-600", bg: "bg-cyan-50" },
            { label: t.soilHealth, value: "High", change: village.soilType, color: "text-emerald-600", bg: "bg-emerald-50" },
            { label: t.avgIncome, value: "$420", change: "+8%", color: "text-purple-600", bg: "bg-purple-50" },
          ].map((stat, i) => (
             <div key={i} className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex flex-col justify-between hover:shadow-md transition-shadow">
                 <div className="flex justify-between items-start">
                    <p className="text-gray-500 text-sm font-semibold">{stat.label}</p>
                    <span className={`text-xs font-bold px-2 py-1 rounded-full ${stat.bg} ${stat.color}`}>{stat.change}</span>
                 </div>
                 <h3 className="text-3xl font-bold text-gray-800 mt-4">{stat.value}</h3>
             </div>
          ))}
       </div>

       <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
           {/* Water Usage Chart */}
           <div className="lg:col-span-2 bg-white rounded-3xl p-8 shadow-sm border border-gray-100">
               <div className="flex justify-between items-center mb-8">
                   <h3 className="text-xl font-bold text-gray-800">{t.waterConsumption}</h3>
                   <select className="bg-gray-50 border border-gray-200 text-gray-600 text-sm rounded-lg px-3 py-1 outline-none">
                       <option>Last 7 Days</option>
                       <option>Last Month</option>
                   </select>
               </div>
               <div className="h-64">
                   <ResponsiveContainer width="100%" height="100%">
                       <AreaChart data={waterData}>
                           <defs>
                               <linearGradient id="colorUsage" x1="0" y1="0" x2="0" y2="1">
                                   <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.8}/>
                                   <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                               </linearGradient>
                           </defs>
                           <XAxis dataKey="name" stroke="#9ca3af" axisLine={false} tickLine={false} />
                           <YAxis stroke="#9ca3af" axisLine={false} tickLine={false} />
                           <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                           <Tooltip contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'}} />
                           <Area type="monotone" dataKey="usage" stroke="#06b6d4" strokeWidth={3} fillOpacity={1} fill="url(#colorUsage)" />
                       </AreaChart>
                   </ResponsiveContainer>
               </div>
           </div>

           {/* Market Snapshot */}
           <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100 flex flex-col">
               <h3 className="text-xl font-bold text-gray-800 mb-6">{t.marketSnapshot}</h3>
               <div className="flex-1 min-h-[200px]">
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={cropData} layout="vertical">
                            <XAxis type="number" hide />
                            <YAxis dataKey="name" type="category" stroke="#6b7280" tick={{fontSize: 12}} width={50} axisLine={false} tickLine={false} />
                            <Tooltip cursor={{fill: 'transparent'}} contentStyle={{borderRadius: '8px'}} />
                            <Bar dataKey="price" barSize={20} radius={[0, 4, 4, 0]}>
                                {cropData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={['#10b981', '#f59e0b', '#3b82f6', '#8b5cf6'][index % 4]} />
                                ))}
                            </Bar>
                        </BarChart>
                    </ResponsiveContainer>
               </div>
               <div className="mt-4 p-4 bg-gray-50 rounded-xl">
                   <p className="text-xs text-gray-500 font-bold uppercase mb-2">{t.liveAlert} for {village.region}</p>
                   <p className="text-sm text-gray-800 font-medium">Regional supply chain stable. Wheat prices trending up in local markets.</p>
               </div>
           </div>
       </div>
    </div>
  );
};
