
import React, { useState, useRef } from 'react';
import { createLessonPlan, solveHomework, generateEducationalImage, generateQuiz, generateSpeech } from '../services/geminiService';
import { QuizItem, Language } from '../types';

export const Education: React.FC<{ language: Language }> = ({ language }) => {
    const [activeTab, setActiveTab] = useState<'tutor' | 'visual' | 'homework' | 'quiz'>('tutor');

    // Tutor State
    const [topic, setTopic] = useState('');
    const [level, setLevel] = useState('');
    const [lessonPlan, setLessonPlan] = useState('');
    const [tutorLoading, setTutorLoading] = useState(false);
    const [isPlaying, setIsPlaying] = useState(false);
    const audioContextRef = useRef<AudioContext | null>(null);

    // Visual State
    const [visualPrompt, setVisualPrompt] = useState('');
    const [generatedImage, setGeneratedImage] = useState('');
    const [visualLoading, setVisualLoading] = useState(false);
    const [visualError, setVisualError] = useState('');

    // Homework State
    const [hwImage, setHwImage] = useState<string | null>(null);
    const [hwMime, setHwMime] = useState('');
    const [hwSolution, setHwSolution] = useState('');
    const [hwLoading, setHwLoading] = useState(false);

    // Quiz State
    const [quizTopic, setQuizTopic] = useState('');
    const [quizLevel, setQuizLevel] = useState('');
    const [quizData, setQuizData] = useState<QuizItem[]>([]);
    const [quizLoading, setQuizLoading] = useState(false);
    const [currentQIndex, setCurrentQIndex] = useState(0);
    const [score, setScore] = useState(0);
    const [showScore, setShowScore] = useState(false);
    const [selectedOption, setSelectedOption] = useState<number | null>(null);
    const [isAnswered, setIsAnswered] = useState(false);

    const handleTutor = async () => {
        if (!topic || !level) return;
        setTutorLoading(true);
        setLessonPlan('');
        try {
            const res = await createLessonPlan(topic, level, language);
            setLessonPlan(res);
        } catch (e) { setLessonPlan("Error creating plan."); }
        finally { setTutorLoading(false); }
    };

    const handleSpeak = async () => {
        if (!lessonPlan || isPlaying) return;
        try {
            setIsPlaying(true);
            const base64Audio = await generateSpeech(lessonPlan.slice(0, 1000));
            
            const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
            audioContextRef.current = ctx;
            
            const binaryString = atob(base64Audio);
            const len = binaryString.length;
            const bytes = new Uint8Array(len);
            for (let i = 0; i < len; i++) {
                bytes[i] = binaryString.charCodeAt(i);
            }
            
            const audioBuffer = await ctx.decodeAudioData(bytes.buffer);
            const source = ctx.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(ctx.destination);
            source.onended = () => setIsPlaying(false);
            source.start(0);
        } catch (e) {
            console.error(e);
            setIsPlaying(false);
        }
    };

    const handleVisual = async () => {
        if (!visualPrompt) return;
        setVisualLoading(true);
        setVisualError('');
        setGeneratedImage('');
        try {
            const res = await generateEducationalImage(visualPrompt);
            setGeneratedImage(res);
        } catch (e: any) { 
            console.error(e);
            setVisualError(e.message || "Image generation failed."); 
        }
        finally { setVisualLoading(false); }
    };

    const handleHwUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setHwMime(file.type);
            const reader = new FileReader();
            reader.onloadend = () => setHwImage(reader.result as string);
            reader.readAsDataURL(file);
        }
    };

    const handleHwSolve = async () => {
        if (!hwImage) return;
        setHwLoading(true);
        try {
            const base64 = hwImage.split(',')[1];
            const res = await solveHomework(base64, hwMime, language);
            setHwSolution(res);
        } catch (e) { setHwSolution("Could not solve."); }
        finally { setHwLoading(false); }
    };

    const handleGenerateQuiz = async () => {
        if(!quizTopic || !quizLevel) return;
        setQuizLoading(true);
        setQuizData([]);
        setShowScore(false);
        setCurrentQIndex(0);
        setScore(0);
        try {
            const res = await generateQuiz(quizTopic, quizLevel, language);
            setQuizData(res);
        } catch (e) { alert("Failed to generate quiz"); }
        finally { setQuizLoading(false); }
    };

    const handleAnswer = (optionIdx: number) => {
        if (isAnswered) return;
        setSelectedOption(optionIdx);
        setIsAnswered(true);
        if (optionIdx === quizData[currentQIndex].correctAnswer) {
            setScore(prev => prev + 1);
        }
    };

    const nextQuestion = () => {
        if (currentQIndex < quizData.length - 1) {
            setCurrentQIndex(prev => prev + 1);
            setSelectedOption(null);
            setIsAnswered(false);
        } else {
            setShowScore(true);
        }
    };

    return (
        <div className="p-6 h-full flex flex-col space-y-4">
            <div className="flex space-x-2 bg-white p-1 rounded-xl shadow-sm border border-indigo-100 w-fit mb-2 overflow-x-auto">
                {['tutor', 'visual', 'homework', 'quiz'].map((tab) => (
                    <button
                        key={tab}
                        onClick={() => setActiveTab(tab as any)}
                        className={`px-4 py-2 rounded-lg text-sm font-bold capitalize transition-all whitespace-nowrap ${
                            activeTab === tab 
                            ? 'bg-indigo-600 text-white shadow-md' 
                            : 'text-gray-500 hover:bg-indigo-50'
                        }`}
                    >
                        {tab === 'tutor' ? 'AI Tutor' : tab === 'visual' ? 'Visual Lab' : tab === 'homework' ? 'Homework Helper' : 'Quiz Arena'}
                    </button>
                ))}
            </div>

            <div className="flex-1 overflow-y-auto">
                {activeTab === 'tutor' && (
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
                        <div className="col-span-1 bg-gradient-to-br from-indigo-800 to-violet-900 rounded-3xl p-6 text-white shadow-xl h-fit">
                            <h3 className="text-2xl font-bold mb-2">Personalized Learning</h3>
                            <div className="space-y-4">
                                <input type="text" className="w-full bg-white/10 border border-indigo-500/30 rounded-lg px-3 py-2 mt-1 focus:ring-2 focus:ring-indigo-400 outline-none text-white placeholder-indigo-400" placeholder="Topic" value={topic} onChange={e => setTopic(e.target.value)} />
                                <input type="text" className="w-full bg-white/10 border border-indigo-500/30 rounded-lg px-3 py-2 mt-1 focus:ring-2 focus:ring-indigo-400 outline-none text-white placeholder-indigo-400" placeholder="Level" value={level} onChange={e => setLevel(e.target.value)} />
                                <button onClick={handleTutor} disabled={tutorLoading || !topic || !level} className="w-full bg-indigo-500 hover:bg-indigo-400 text-white font-bold py-3 rounded-xl mt-4 transition-colors disabled:opacity-50">
                                    {tutorLoading ? 'Designing Plan...' : 'Create Lesson Plan'}
                                </button>
                            </div>
                        </div>
                        <div className="col-span-1 lg:col-span-2 bg-white rounded-3xl p-8 shadow-sm border border-indigo-50 overflow-y-auto min-h-[400px] relative">
                            {lessonPlan && (
                                <button onClick={handleSpeak} disabled={isPlaying} className="absolute top-6 right-6 p-3 bg-indigo-100 hover:bg-indigo-200 text-indigo-700 rounded-full transition-colors z-10">
                                    {isPlaying ? 'Speaking...' : 'Read Aloud'}
                                </button>
                            )}
                            {lessonPlan ? <div className="prose prose-indigo max-w-none whitespace-pre-wrap">{lessonPlan}</div> : <p className="text-gray-400 text-center">Enter topic and level</p>}
                        </div>
                    </div>
                )}
                {/* Visual Lab - largely same as before, no lang dependency for visual */}
                {activeTab === 'visual' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 h-full">
                        <div className="flex flex-col bg-white rounded-3xl p-6 shadow-sm border border-indigo-50">
                            <h3 className="text-xl font-bold text-gray-800 mb-2">Visual Learning Lab</h3>
                            <textarea className="flex-1 bg-gray-50 border border-gray-200 rounded-xl p-4 mb-4 focus:ring-2 focus:ring-indigo-500 outline-none resize-none" placeholder="Describe diagram..." value={visualPrompt} onChange={e => setVisualPrompt(e.target.value)}></textarea>
                            <button onClick={handleVisual} disabled={visualLoading || !visualPrompt} className="w-full bg-violet-600 text-white font-bold py-3 rounded-xl hover:bg-violet-700 transition-colors disabled:opacity-50">
                                {visualLoading ? 'Generating...' : 'Generate Diagram'}
                            </button>
                        </div>
                        <div className="bg-gray-100 rounded-3xl flex items-center justify-center relative overflow-hidden group border border-gray-200 shadow-inner">
                            {generatedImage ? <img src={generatedImage} alt="Edu" className="w-full h-full object-contain" /> : <p className="text-gray-400">Visual Output</p>}
                        </div>
                    </div>
                )}
                {/* Homework Helper */}
                {activeTab === 'homework' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 h-full">
                        <div className="bg-white rounded-3xl p-6 shadow-sm border border-indigo-50 flex flex-col">
                            <h3 className="text-xl font-bold text-gray-800 mb-4">Homework Scanner</h3>
                            <div className="flex-1 border-2 border-dashed border-indigo-200 rounded-2xl flex items-center justify-center bg-indigo-50/30 relative overflow-hidden group hover:bg-indigo-50 transition-colors min-h-[250px]">
                                {hwImage ? <img src={hwImage} className="max-h-64 object-contain z-10" alt="Homework" /> : <p className="text-indigo-400">Upload Image</p>}
                                <input type="file" accept="image/*" onChange={handleHwUpload} className="absolute inset-0 opacity-0 cursor-pointer z-20" />
                            </div>
                            <button onClick={handleHwSolve} disabled={!hwImage || hwLoading} className="mt-4 w-full bg-indigo-600 text-white py-3 rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-colors">
                                {hwLoading ? 'Solving...' : 'Explain Solution'}
                            </button>
                        </div>
                        <div className="bg-white rounded-3xl p-8 shadow-sm border border-indigo-50 overflow-y-auto">
                            {hwSolution ? <div className="prose prose-indigo max-w-none whitespace-pre-wrap">{hwSolution}</div> : <p className="text-gray-400 text-center">Solution will appear here</p>}
                        </div>
                    </div>
                )}
                {/* Quiz Arena */}
                {activeTab === 'quiz' && (
                    <div className="flex flex-col h-full bg-white rounded-3xl p-8 shadow-sm border border-indigo-50">
                        {quizData.length === 0 ? (
                             <div className="max-w-md mx-auto w-full flex flex-col items-center justify-center h-full space-y-4">
                                <h2 className="text-2xl font-bold text-gray-800">Knowledge Check</h2>
                                <input type="text" placeholder="Topic" className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3" value={quizTopic} onChange={e => setQuizTopic(e.target.value)} />
                                <input type="text" placeholder="Level" className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3" value={quizLevel} onChange={e => setQuizLevel(e.target.value)} />
                                <button onClick={handleGenerateQuiz} disabled={quizLoading} className="w-full bg-indigo-600 text-white font-bold py-3 rounded-xl hover:bg-indigo-700 transition-colors disabled:opacity-50">
                                    {quizLoading ? 'Generating...' : 'Start Quiz'}
                                </button>
                             </div>
                        ) : showScore ? (
                            <div className="flex flex-col items-center justify-center h-full">
                                <h2 className="text-3xl font-bold text-indigo-900 mb-2">Complete!</h2>
                                <div className="text-6xl font-black text-indigo-600 mb-8">{score} / {quizData.length}</div>
                                <button onClick={() => setQuizData([])} className="px-8 py-3 border-2 border-indigo-600 text-indigo-700 font-bold rounded-xl">New Quiz</button>
                            </div>
                        ) : (
                            <div className="max-w-3xl mx-auto w-full h-full flex flex-col">
                                <span className="text-sm font-bold text-gray-400 uppercase tracking-widest">Question {currentQIndex + 1}/{quizData.length}</span>
                                <h3 className="text-2xl font-bold text-gray-800 mb-8">{quizData[currentQIndex].question}</h3>
                                <div className="grid grid-cols-1 gap-4 mb-8">
                                    {quizData[currentQIndex].options.map((option, idx) => (
                                        <button key={idx} onClick={() => handleAnswer(idx)} disabled={isAnswered} className={`p-4 rounded-xl border-2 text-left font-medium transition-all ${isAnswered ? (idx === quizData[currentQIndex].correctAnswer ? "bg-green-100 border-green-400 text-green-800" : idx === selectedOption ? "bg-red-100 border-red-400 text-red-800" : "bg-gray-50 border-gray-200") : "bg-gray-50 border-gray-200 hover:bg-indigo-50"}`}>{option}</button>
                                    ))}
                                </div>
                                {isAnswered && <div className="bg-blue-50 p-4 rounded-xl border border-blue-100 mb-6"><p className="text-blue-900 font-medium text-sm"><span className="font-bold">Explanation:</span> {quizData[currentQIndex].explanation}</p></div>}
                                <div className="mt-auto text-right"><button onClick={nextQuestion} disabled={!isAnswered} className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 transition-colors">{currentQIndex === quizData.length - 1 ? 'Finish' : 'Next'}</button></div>
                            </div>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};
