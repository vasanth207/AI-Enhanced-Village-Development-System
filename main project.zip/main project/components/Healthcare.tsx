
import React, { useState, useEffect } from 'react';
import { analyzeSymptoms, findHospitals } from '../services/geminiService';
import { Village, Language } from '../types';

export const Healthcare: React.FC<{ village: Village; language: Language }> = ({ village, language }) => {
    const [symptoms, setSymptoms] = useState('');
    const [triageResult, setTriageResult] = useState('');
    const [loading, setLoading] = useState(false);
    const [locationInput, setLocationInput] = useState(village.location);
    const [clinics, setClinics] = useState('');
    const [findingClinics, setFindingClinics] = useState(false);

    useEffect(() => {
        setLocationInput(village.location);
    }, [village]);

    const handleTriage = async () => {
        if(!symptoms) return;
        setLoading(true);
        try {
            const res = await analyzeSymptoms(symptoms, language);
            setTriageResult(res);
        } catch(e) { setTriageResult("Error during analysis."); }
        finally { setLoading(false); }
    };

    const handleFindClinics = async () => {
        if (!locationInput) return;
        setFindingClinics(true);
        try {
            const res = await findHospitals(locationInput, language);
            setClinics(res);
        } catch(e) { setClinics("Could not find clinics."); }
        finally { setFindingClinics(false); }
    };

    return (
        <div className="p-6 h-full grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-red-50 flex flex-col">
                <h2 className="text-2xl font-bold text-gray-800 mb-2">AI Health Triage</h2>
                <textarea 
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl p-4 mb-4 focus:outline-none focus:ring-2 focus:ring-red-200 resize-none h-32"
                    placeholder="Describe symptoms..."
                    value={symptoms}
                    onChange={e => setSymptoms(e.target.value)}
                ></textarea>
                <button onClick={handleTriage} disabled={loading || !symptoms} className="w-full bg-red-500 text-white font-bold py-3 rounded-xl hover:bg-red-600 transition-colors shadow-md disabled:opacity-50">
                    {loading ? 'Analyzing...' : 'Check Symptoms'}
                </button>
                <div className="mt-6 flex-1 overflow-y-auto bg-red-50/50 rounded-xl p-4 border border-red-100">
                    {triageResult ? <div className="prose prose-red text-sm whitespace-pre-wrap">{triageResult}</div> : <div className="text-gray-400 text-center text-sm">Results will appear here.</div>}
                </div>
            </div>

            <div className="bg-white rounded-3xl p-6 shadow-sm border border-blue-50 flex flex-col h-full">
                <h3 className="font-bold text-gray-800 text-lg mb-2">Nearest Medical Centers</h3>
                <div className="flex gap-2 mb-4">
                    <input type="text" className="flex-1 bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500" value={locationInput} onChange={(e) => setLocationInput(e.target.value)} />
                    <button onClick={handleFindClinics} disabled={findingClinics || !locationInput} className="bg-blue-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-blue-700 disabled:opacity-50 transition-colors">
                        {findingClinics ? '...' : 'Find'}
                    </button>
                </div>
                <div className="flex-1 bg-blue-50/30 rounded-2xl overflow-y-auto p-4 border border-blue-50 relative">
                        {clinics ? <div className="prose prose-blue max-w-none text-sm" dangerouslySetInnerHTML={{ __html: clinics.replace(/\n/g, '<br/>') }} /> : <p className="text-center text-gray-400">No location selected</p>}
                </div>
            </div>
        </div>
    );
};
