
import React from 'react';
import { UserRole } from '../types';

interface LandingPageProps {
  onSelectPortal: (role: UserRole) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onSelectPortal }) => {
  return (
    <div className="min-h-screen bg-gray-900 relative overflow-hidden flex flex-col items-center justify-center p-6 font-sans">
      {/* Dynamic Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-full bg-[url('https://images.unsplash.com/photo-1625246333195-58197bd47d26?q=80&w=2071&auto=format&fit=crop')] bg-cover bg-center opacity-20"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/80 to-transparent"></div>
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-emerald-500 rounded-full mix-blend-screen filter blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-indigo-500 rounded-full mix-blend-screen filter blur-3xl opacity-20 animate-pulse animation-delay-2000"></div>
      </div>

      <div className="relative z-10 text-center max-w-4xl w-full">
        {/* Header */}
        <div className="mb-12 animate-fade-in-down">
           <div className="inline-flex items-center justify-center p-3 bg-white/10 backdrop-blur-md rounded-2xl mb-6 border border-white/10 shadow-2xl">
              <span className="text-3xl mr-2">🌿</span>
              <h1 className="text-4xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-200 tracking-tight">
                AI Village Development System
              </h1>
           </div>
           <p className="text-gray-300 text-lg md:text-xl max-w-2xl mx-auto leading-relaxed">
             Empowering rural India with next-generation technology. 
             Seamlessly connecting citizens, agriculture, and governance through Artificial Intelligence.
           </p>
        </div>

        {/* Portals */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full">
            {/* GramUday Portal */}
            <button 
              onClick={() => onSelectPortal('citizen')}
              className="group relative bg-white/5 backdrop-blur-sm border border-emerald-500/30 rounded-3xl p-8 hover:bg-emerald-900/20 transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_0_30px_rgba(16,185,129,0.3)] text-left flex flex-col overflow-hidden"
            >
               <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
                  <svg className="w-32 h-32" fill="currentColor" viewBox="0 0 24 24"><path d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" stroke="none" /></svg>
               </div>
               <div className="w-16 h-16 bg-emerald-500 rounded-2xl flex items-center justify-center mb-6 shadow-lg group-hover:scale-110 transition-transform">
                  <span className="text-3xl">🌾</span>
               </div>
               <h2 className="text-3xl font-bold text-white mb-2">GramUday</h2>
               <p className="text-emerald-200 text-sm mb-6">Citizen Portal</p>
               <p className="text-gray-400 text-sm leading-relaxed">
                 Access smart agriculture tools, water management, healthcare, education, and apply for government schemes.
               </p>
               <div className="mt-auto pt-6 flex items-center text-emerald-400 font-bold text-sm uppercase tracking-wider group-hover:translate-x-2 transition-transform">
                  Enter Portal <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
               </div>
            </button>

            {/* Panchayat Admin Portal */}
            <button 
              onClick={() => onSelectPortal('official')}
              className="group relative bg-white/5 backdrop-blur-sm border border-indigo-500/30 rounded-3xl p-8 hover:bg-indigo-900/20 transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_0_30px_rgba(99,102,241,0.3)] text-left flex flex-col overflow-hidden"
            >
               <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
                  <svg className="w-32 h-32" fill="currentColor" viewBox="0 0 24 24"><path d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" stroke="none" /></svg>
               </div>
               <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg group-hover:scale-110 transition-transform">
                  <span className="text-3xl">🏛️</span>
               </div>
               <h2 className="text-3xl font-bold text-white mb-2">Panchayat Admin</h2>
               <p className="text-indigo-200 text-sm mb-6">Official Portal</p>
               <p className="text-gray-400 text-sm leading-relaxed">
                 Manage grievances, approve applications, issue certificates, and oversee village infrastructure planning.
               </p>
               <div className="mt-auto pt-6 flex items-center text-indigo-400 font-bold text-sm uppercase tracking-wider group-hover:translate-x-2 transition-transform">
                  Access Dashboard <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
               </div>
            </button>
        </div>

        <div className="mt-12 text-gray-500 text-sm">
           &copy; 2025 AI Village Development System. Powered by Google Gemini.
        </div>
      </div>
    </div>
  );
};
