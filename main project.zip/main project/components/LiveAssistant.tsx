
import React, { useEffect, useRef, useState, useCallback } from 'react';
import { ai } from '../services/geminiService';
import { Modality, LiveServerMessage } from '@google/genai';
import { Village, Language } from '../types';
import { translations } from '../translations';

// Audio Helpers
const decode = (base64: string) => {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
};

const createBlob = (data: Float32Array) => {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  let binary = '';
  const bytes = new Uint8Array(int16.buffer);
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return {
    data: btoa(binary),
    mimeType: 'audio/pcm;rate=16000',
  };
};

export const LiveAssistant: React.FC<{ village?: Village; language: Language }> = ({ village, language }) => {
  const [active, setActive] = useState(false);
  const [status, setStatus] = useState<'disconnected' | 'connecting' | 'connected'>('disconnected');
  const t = translations[language].live;
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null); 
  const nextStartTime = useRef(0);

  const villageName = village ? village.name : 'the village';

  const startSession = async () => {
    try {
      setStatus('connecting');
      
      const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      audioContextRef.current = outputAudioContext;
      inputAudioContextRef.current = inputAudioContext;
      
      const outputNode = outputAudioContext.createGain();
      outputNode.connect(outputAudioContext.destination);

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const source = inputAudioContext.createMediaStreamSource(stream);
      const scriptProcessor = inputAudioContext.createScriptProcessor(4096, 1, 1);
      
      // Determine voice instructions based on language
      const langInstruction = language === 'kn' ? "Speak ONLY in Kannada." : language === 'hi' ? "Speak ONLY in Hindi." : "Speak in English.";
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: {
          onopen: () => {
            console.log('Live Session Opened');
            setStatus('connected');
            setActive(true);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createBlob(inputData);
              sessionPromise.then(session => {
                 session.sendRealtimeInput({ media: pcmBlob });
              });
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputAudioContext.destination);
          },
          onmessage: async (msg: LiveServerMessage) => {
            const base64Audio = msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio) {
              const binary = decode(base64Audio);
              const dataInt16 = new Int16Array(binary.buffer);
              const buffer = outputAudioContext.createBuffer(1, dataInt16.length, 24000);
              const channelData = buffer.getChannelData(0);
              for(let i=0; i<dataInt16.length; i++) {
                channelData[i] = dataInt16[i] / 32768.0;
              }

              const audioSource = outputAudioContext.createBufferSource();
              audioSource.buffer = buffer;
              audioSource.connect(outputNode);
              
              nextStartTime.current = Math.max(nextStartTime.current, outputAudioContext.currentTime);
              audioSource.start(nextStartTime.current);
              nextStartTime.current += buffer.duration;
            }
          },
          onclose: () => {
            setStatus('disconnected');
            setActive(false);
          },
          onerror: (err) => {
            console.error(err);
            setStatus('disconnected');
            setActive(false);
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: `You are the Elder AI of ${villageName}. ${langInstruction} Speak with wisdom, brevity, and a warm tone. Help manage village resources.`,
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } }
          }
        }
      });
      
      sessionRef.current = sessionPromise;

    } catch (e) {
      console.error("Failed to start live session", e);
      setStatus('disconnected');
    }
  };

  const stopSession = () => {
     if (sessionRef.current) {
        sessionRef.current.then((s: any) => s.close());
     }
     if (audioContextRef.current) audioContextRef.current.close();
     if (inputAudioContextRef.current) inputAudioContextRef.current.close();
     setActive(false);
     setStatus('disconnected');
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <div className={`transition-all duration-300 transform ${active ? 'scale-110' : 'scale-100'}`}>
        <button
          onClick={active ? stopSession : startSession}
          className={`flex items-center justify-center w-16 h-16 rounded-full shadow-2xl border-4 ${
            status === 'connected' ? 'bg-red-500 border-red-300 animate-pulse' : 
            status === 'connecting' ? 'bg-yellow-500 border-yellow-300' : 
            'bg-emerald-600 border-emerald-400 hover:bg-emerald-500'
          } text-white transition-colors`}
        >
          {status === 'connecting' ? (
             <svg className="animate-spin h-8 w-8 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
               <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
               <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
             </svg>
          ) : (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
            </svg>
          )}
        </button>
      </div>
      {active && (
        <div className="absolute bottom-20 right-0 bg-white/90 backdrop-blur-md p-4 rounded-xl shadow-lg border border-emerald-100 w-64">
           <p className="text-sm font-semibold text-emerald-800">{villageName} {t.council}</p>
           <p className="text-xs text-gray-500 mt-1">{t.listening}</p>
           <div className="mt-2 h-1 bg-gray-200 rounded-full overflow-hidden">
             <div className="h-full bg-emerald-500 animate-pulse w-2/3"></div>
           </div>
        </div>
      )}
    </div>
  );
};
