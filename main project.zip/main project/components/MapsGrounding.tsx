
import React, { useState, useEffect } from 'react';
import { findNearbyResources } from '../services/geminiService';
import { Village, Language } from '../types';

export const MapsGrounding: React.FC<{ village: Village; language: Language }> = ({ village, language }) => {
    const [query, setQuery] = useState('');
    const [result, setResult] = useState('');
    const [loading, setLoading] = useState(false);
    const [location, setLocation] = useState<{lat: number, lng: number} | null>(null);

    useEffect(() => {
        setLocation(village.coordinates);
    }, [village]);

    const handleSearch = async () => {
        if (!location || !query) return;
        setLoading(true);
        try {
            const res = await findNearbyResources(query, location.lat, location.lng, language);
            setResult(res);
        } catch (e) {
            setResult("Could not fetch map data.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="p-6 h-full flex flex-col">
            <div className="bg-white rounded-2xl shadow-sm border border-emerald-100 p-8">
                <h2 className="text-2xl font-bold text-gray-800 mb-4">{village.name} Resource Locator</h2>
                <div className="flex gap-4">
                    <input 
                        type="text" 
                        value={query} 
                        onChange={(e) => setQuery(e.target.value)}
                        placeholder="e.g., 'Hardware stores nearby' or 'Farmers markets'"
                        className="flex-1 border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                    <button 
                        onClick={handleSearch}
                        disabled={loading || !location}
                        className="bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-emerald-700 disabled:opacity-50"
                    >
                        {loading ? 'Searching...' : 'Find'}
                    </button>
                </div>
            </div>

            <div className="mt-6 bg-white rounded-2xl shadow-sm border border-emerald-100 p-8 flex-1 overflow-y-auto">
                 {result ? (
                    <div className="prose prose-emerald max-w-none">
                        <div dangerouslySetInnerHTML={{ __html: result.replace(/\n/g, '<br/>') }} />
                    </div>
                 ) : (
                    <div className="flex flex-col items-center justify-center h-full text-gray-400">
                        <p>Enter a query to locate village resources</p>
                    </div>
                 )}
            </div>
        </div>
    );
};
