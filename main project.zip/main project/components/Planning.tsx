
import React, { useState } from 'react';
import { generateVillagePlan, generatePlanVisualization } from '../services/geminiService';
import { PlanProposal, Village, Language } from '../types';

export const Planning: React.FC<{ village: Village; language: Language }> = ({ village, language }) => {
  const [prompt, setPrompt] = useState('');
  const [budget, setBudget] = useState(10000);
  const [isThinking, setIsThinking] = useState(false);
  const [isGeneratingImg, setIsGeneratingImg] = useState(false);
  const [plan, setPlan] = useState<PlanProposal | null>(null);

  const handleGenerate = async () => {
    if (!prompt) return;
    setIsThinking(true);
    setPlan(null);
    try {
      const fullPrompt = `Plan for ${village.name}: ${prompt}`;
      const result = await generateVillagePlan(fullPrompt, budget, language);
      setPlan(result);
      setIsThinking(false);
      
      setIsGeneratingImg(true);
      const imgUrl = await generatePlanVisualization(result.description);
      setPlan(prev => prev ? { ...prev, imageUrl: imgUrl } : null);
    } catch (e) {
      console.error(e);
      alert("Planning failed. Gemini might be busy.");
    } finally {
      setIsThinking(false);
      setIsGeneratingImg(false);
    }
  };

  return (
    <div className="p-6 h-full flex flex-col space-y-6">
      <div className="bg-gradient-to-r from-emerald-900 to-teal-900 rounded-3xl p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white opacity-5 rounded-full -mr-16 -mt-16 blur-2xl"></div>
        <h2 className="text-3xl font-bold mb-2">{village.name} Infrastructure Planner</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-2">
             <label className="block text-xs uppercase tracking-wider text-emerald-300 mb-1">Project Goal</label>
             <input 
               type="text" 
               className="w-full bg-white/10 border border-emerald-500/30 rounded-xl px-4 py-3 text-white placeholder-emerald-400 focus:outline-none focus:ring-2 focus:ring-emerald-400"
               placeholder="e.g., Build a solar-powered community library..."
               value={prompt}
               onChange={(e) => setPrompt(e.target.value)}
             />
          </div>
          <div>
             <label className="block text-xs uppercase tracking-wider text-emerald-300 mb-1">Budget ($)</label>
             <input 
               type="number" 
               className="w-full bg-white/10 border border-emerald-500/30 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-emerald-400"
               value={budget}
               onChange={(e) => setBudget(parseInt(e.target.value))}
             />
          </div>
        </div>
        
        <button 
          onClick={handleGenerate}
          disabled={isThinking || !prompt}
          className="mt-6 bg-emerald-400 hover:bg-emerald-300 text-emerald-950 font-bold py-3 px-8 rounded-full shadow-lg transition-transform transform hover:scale-105 disabled:opacity-50 disabled:scale-100 flex items-center"
        >
          {isThinking ? "AI Reasoning..." : "Generate Plan"}
        </button>
      </div>

      {(isThinking || plan) && (
         <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 flex-1 min-h-0">
             <div className="bg-white rounded-2xl shadow-sm border border-emerald-100 p-6 overflow-y-auto">
                {isThinking ? (
                   <div className="animate-pulse space-y-4">
                     <div className="h-6 bg-gray-200 rounded w-1/3"></div>
                     <div className="space-y-2">
                        <div className="h-4 bg-gray-200 rounded"></div>
                        <div className="h-4 bg-gray-200 rounded"></div>
                     </div>
                   </div>
                ) : plan ? (
                   <>
                      <h3 className="text-2xl font-bold text-gray-800 mb-2">{plan.title}</h3>
                      <div className="space-y-4 text-gray-600">
                         <div>
                            <h4 className="text-sm font-bold text-gray-900 uppercase tracking-wide">Description</h4>
                            <p className="mt-1">{plan.description}</p>
                         </div>
                         <div>
                            <h4 className="text-sm font-bold text-gray-900 uppercase tracking-wide">Strategic Impact</h4>
                            <p className="mt-1">{plan.impact}</p>
                         </div>
                         <div className="bg-red-50 p-4 rounded-xl border border-red-100">
                            <h4 className="text-sm font-bold text-red-900 uppercase tracking-wide">Risk Assessment</h4>
                            <p className="mt-1 text-red-800 text-sm">{plan.riskAssessment}</p>
                         </div>
                      </div>
                   </>
                ) : null}
             </div>
             <div className="bg-gray-100 rounded-2xl shadow-inner flex items-center justify-center overflow-hidden relative group">
                {isGeneratingImg ? (
                   <div className="text-center">
                      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600 mx-auto mb-3"></div>
                      <p className="text-gray-500 text-sm">Rendering Architecture...</p>
                   </div>
                ) : plan?.imageUrl ? (
                   <img src={plan.imageUrl} alt="Visualization" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                ) : (
                    <div className="text-gray-400 flex flex-col items-center">
                       <p>Visualization Area</p>
                    </div>
                )}
             </div>
         </div>
      )}
    </div>
  );
};
