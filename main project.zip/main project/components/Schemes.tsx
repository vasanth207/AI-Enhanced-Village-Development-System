
import React, { useState, useEffect } from 'react';
import { findEligibleSchemes } from '../services/geminiService';
import { Scheme, Language } from '../types';

export const PANCHAYAT_SCHEMES: Scheme[] = [
  // --- EMPLOYMENT ---
  {
    id: 'c1',
    name: 'MGNREGA',
    category: 'Employment',
    description: 'Mahatma Gandhi National Rural Employment Guarantee Act. 100 days guaranteed wage employment. Focuses on water conservation, roads, and ponds.',
    benefits: 'Guaranteed daily wage employment',
    eligibility: 'Rural households willing to do unskilled manual work'
  },
  {
    id: 'c5',
    name: 'PMGSY (Pradhan Mantri Gram Sadak Yojana)',
    category: 'Employment',
    description: 'Connecting rural villages with all-weather roads. Priority for remote & tribal areas.',
    benefits: 'Better road connectivity',
    eligibility: 'Unconnected rural habitations'
  },
  {
    id: 'c9',
    name: 'DDU-GKY (Deen Dayal Upadhyaya Grameen Kaushalya Yojana)',
    category: 'Employment',
    description: 'Skill development and job placement assistance for rural youth.',
    benefits: 'Free skill training & placement',
    eligibility: 'Rural youth (15-35 years)'
  },

  // --- HOUSING & INFRASTRUCTURE ---
  {
    id: 'c2',
    name: 'PMAY-G (Pradhan Mantri Awaas Yojana)',
    category: 'Housing',
    description: 'Housing for rural poor. Beneficiary selection via SECC data. Includes financial aid for construction and toilets.',
    benefits: 'Financial aid for house construction',
    eligibility: 'Homeless or living in kutcha houses (SECC list)'
  },
  {
    id: 'c4',
    name: 'Jal Jeevan Mission (JJM)',
    category: 'Housing',
    description: 'Household tap water connections and water quality monitoring via Village Water & Sanitation Committees.',
    benefits: 'Functional Household Tap Connection (FHTC)',
    eligibility: 'Rural households lacking tap water'
  },
  {
    id: 'c3',
    name: 'Swachh Bharat Mission (SBM-G)',
    category: 'Health',
    description: 'Toilets in every household. Solid & liquid waste management for ODF+ villages.',
    benefits: 'Sanitation facilities & cleaner villages',
    eligibility: 'Rural households without toilets'
  },

  // --- AGRICULTURE ---
  {
    id: 'c13',
    name: 'PM-Kisan Samman Nidhi',
    category: 'Agriculture',
    description: 'Income support of ₹6,000 yearly to farmers. Beneficiary verification at village level.',
    benefits: '₹6,000/year direct transfer',
    eligibility: 'Landholding farmer families'
  },
  {
    id: 'c19',
    name: 'PM Fasal Bima Yojana (PMFBY)',
    category: 'Agriculture',
    description: 'Crop insurance scheme providing financial support to farmers suffering crop loss/damage arising from unforeseen events.',
    benefits: 'Insurance cover for crop loss',
    eligibility: 'Farmers including sharecroppers/tenant farmers'
  },
  {
    id: 'c22',
    name: 'Soil Health Card Scheme',
    category: 'Agriculture',
    description: 'Provides information to farmers on nutrient status of their soil along with recommendation on appropriate dosage of nutrients.',
    benefits: 'Soil test report & fertilizer recommendations',
    eligibility: 'All farmers'
  },
  {
    id: 'c23',
    name: 'Kisan Credit Card (KCC)',
    category: 'Agriculture',
    description: 'Provides adequate and timely credit support from the banking system to the farmers for their cultivation and other needs.',
    benefits: 'Easy access to credit/loans',
    eligibility: 'Farmers, tenant farmers, sharecroppers'
  },
  {
    id: 'c8',
    name: 'PMKSY (Pradhan Mantri Krishi Sinchai Yojana)',
    category: 'Agriculture',
    description: 'Irrigation development, water harvesting structures, and promotion of drip/sprinkler irrigation.',
    benefits: 'Subsidies for irrigation equipment',
    eligibility: 'Farmers with cultivable land'
  },

  // --- FINANCIAL & LIVELIHOOD ---
  {
    id: 'c6',
    name: 'NRLM (National Rural Livelihood Mission)',
    category: 'Financial',
    description: 'Women Self-Help Groups (SHGs) for loans, financial support, and entrepreneurship training.',
    benefits: 'Low-interest loans & skill training',
    eligibility: 'Rural women joining SHGs'
  },
  {
    id: 'c15',
    name: 'NSAP (National Social Assistance Programme)',
    category: 'Financial',
    description: 'Social security pensions for elderly, widows, and disabled persons.',
    benefits: 'Monthly Pension (Old age/Widow/Disability)',
    eligibility: 'BPL individuals, 60+ age, widows, or disabled'
  },
  {
    id: 'c16',
    name: 'Sukanya Samriddhi Yojana',
    category: 'Financial',
    description: 'Small deposit scheme for the girl child meant to meet education and marriage expenses.',
    benefits: 'High interest rate, tax benefits',
    eligibility: 'Girl child below 10 years'
  },
  {
    id: 'c17',
    name: 'Atal Pension Yojana (APY)',
    category: 'Financial',
    description: 'Pension scheme for citizens of India primarily focused on the unorganized sector.',
    benefits: 'Guaranteed minimum pension at age 60',
    eligibility: 'Citizens aged 18-40 years'
  },
  {
    id: 'c18',
    name: 'PMJJBY / PMSBY',
    category: 'Financial',
    description: 'Life insurance (PMJJBY) and Accidental insurance (PMSBY) at very low premiums.',
    benefits: 'Insurance cover of ₹2 Lakhs',
    eligibility: 'Bank account holders (18-50/70 years)'
  },
  {
    id: 'c10',
    name: 'Stand-Up India / Mudra Yojana',
    category: 'Financial',
    description: 'Loans for small businesses and rural entrepreneurship implemented via Panchayat outreach.',
    benefits: 'Business loans (₹50k - ₹1Cr)',
    eligibility: 'SC/ST, Women, Small Entrepreneurs'
  },

  // --- HEALTH ---
  {
    id: 'c14',
    name: 'Ayushman Bharat (PM-JAY)',
    category: 'Health',
    description: 'Health insurance coverage of ₹5 lakh per family per year for secondary/tertiary care.',
    benefits: 'Free health insurance up to ₹5 Lakh',
    eligibility: 'Low-income families (SECC data)'
  },
  {
    id: 'c20',
    name: 'Janani Suraksha Yojana (JSY)',
    category: 'Health',
    description: 'Safe motherhood intervention promoting institutional delivery to reduce maternal and neo-natal mortality.',
    benefits: 'Cash assistance for institutional delivery',
    eligibility: 'Pregnant women (BPL/SC/ST)'
  },
  {
    id: 'c21',
    name: 'Mission Indradhanush',
    category: 'Health',
    description: 'Full immunization coverage for children and pregnant women against vaccine-preventable diseases.',
    benefits: 'Free vaccination against 12 diseases',
    eligibility: 'Children under 2 years and pregnant women'
  },
  {
    id: 'c7',
    name: 'Poshan Abhiyan',
    category: 'Health',
    description: 'Nutrition programs for pregnant women & children supported by Panchayats and Anganwadis.',
    benefits: 'Nutritional supplements & monitoring',
    eligibility: 'Children (0-6y), Pregnant/Lactating women'
  },

  // --- EDUCATION & GOVERNANCE ---
  {
    id: 'c24',
    name: 'Samagra Shiksha Abhiyan',
    category: 'Education',
    description: 'Integrated scheme for school education extending from pre-school to class 12.',
    benefits: 'Quality education, digital initiatives',
    eligibility: 'School-going children'
  },
  {
    id: 'c11',
    name: 'GPDP (Gram Panchayat Development Plan)',
    category: 'Financial',
    description: 'Annual planning for village needs like roads, water, sanitation, health, and education via Gram Sabha.',
    benefits: 'Community development funds',
    eligibility: 'Entire Village Community'
  },
  {
    id: 'c12',
    name: 'Digital India / e-Panchayat',
    category: 'Education',
    description: 'Online birth/death certificates, property tax, and Panchayat information systems.',
    benefits: 'Digital governance services',
    eligibility: 'All citizens'
  },

  // --- KARNATAKA STATE SCHEMES ---
  {
    id: 'k1',
    name: 'Gruha Lakshmi (Karnataka)',
    category: 'Financial',
    description: 'Financial assistance for the woman head of the family.',
    benefits: '₹2,000 per month',
    eligibility: 'Woman head of family (BPL/APL), non-taxpayer'
  },
  {
    id: 'k2',
    name: 'Bhagya Lakshmi (Karnataka)',
    category: 'Financial',
    description: 'Welfare scheme for the girl child in BPL families. Financial bonds matured at age 18.',
    benefits: 'Health insurance & maturity bond upto ₹1 Lakh',
    eligibility: 'Girl child in BPL family (Max 2 children)'
  },
  {
    id: 'k6',
    name: 'Yashasvini Scheme (Karnataka)',
    category: 'Health',
    description: 'Co-operative farmers health care scheme.',
    benefits: 'Cashless surgical treatment',
    eligibility: 'Rural co-operative society members'
  },
  {
    id: 'k3',
    name: 'Punyakoti Dattu Yojana (Karnataka)',
    category: 'Agriculture',
    description: 'Cattle adoption scheme encouraging citizens to adopt cows in gaushalas.',
    benefits: 'Support for cattle feed & shelter',
    eligibility: 'Open for public contribution/adoption'
  },
  {
    id: 'k4',
    name: 'Ksheera Bhagya (Karnataka)',
    category: 'Health',
    description: 'Provision of milk to school and Anganwadi children to tackle malnutrition.',
    benefits: 'Free milk 5 days a week',
    eligibility: 'Students in Govt/Aided schools & Anganwadis'
  },
  {
    id: 'k5',
    name: 'Krishi Bhagya (Karnataka)',
    category: 'Agriculture',
    description: 'Rainwater harvesting and sustainable farming in rain-fed regions.',
    benefits: 'Subsidies for farm ponds & polyhouses',
    eligibility: 'Farmers in dry-land zones'
  },

  // --- TAMIL NADU STATE SCHEMES ---
  {
    id: 'tn1',
    name: 'Kalaignar Magalir Urimai Thogai (Tamil Nadu)',
    category: 'Financial',
    description: 'Basic income scheme for women heads of households.',
    benefits: '₹1,000 per month',
    eligibility: 'Women heads of eligible households'
  },
  {
    id: 'tn2',
    name: 'Aavin & Rural Milk Schemes (Tamil Nadu)',
    category: 'Agriculture',
    description: 'Support for dairy farmers via cooperative milk procurement.',
    benefits: 'Subsidies on cattle feed & milk procurement',
    eligibility: 'Dairy farmers in cooperatives'
  },

  // --- KERALA STATE SCHEMES ---
  {
    id: 'kl1',
    name: 'Kudumbashree Mission (Kerala)',
    category: 'Financial',
    description: 'Poverty eradication and women empowerment through neighborhood groups (NHGs).',
    benefits: 'Micro-credit, livelihood support',
    eligibility: 'Women residents'
  },
  {
    id: 'kl2',
    name: 'Haritha Kerala Mission (Kerala)',
    category: 'Health',
    description: 'Focus on sanitation, waste management, and organic farming.',
    benefits: 'Clean environment & agricultural support',
    eligibility: 'Community participation'
  }
];

export const Schemes: React.FC<{ language: Language }> = ({ language }) => {
  const [activeTab, setActiveTab] = useState<'directory' | 'ai'>('directory');
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('All');
  
  const [userProfile, setUserProfile] = useState('');
  const [aiResult, setAiResult] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  
  const [allSchemes, setAllSchemes] = useState<Scheme[]>(PANCHAYAT_SCHEMES);

  useEffect(() => {
      // Load custom schemes added by admin
      try {
          const stored = localStorage.getItem('gramuday_custom_schemes');
          if (stored) {
              const customSchemes = JSON.parse(stored) as Scheme[];
              setAllSchemes([...customSchemes, ...PANCHAYAT_SCHEMES]);
          }
      } catch(e) {}
  }, []);

  const filteredSchemes = allSchemes.filter(s => {
    const matchesSearch = s.name.toLowerCase().includes(search.toLowerCase()) || s.description.toLowerCase().includes(search.toLowerCase());
    const matchesFilter = filter === 'All' || s.category === filter;
    return matchesSearch && matchesFilter;
  });

  const handleCheckEligibility = async () => {
    if (!userProfile) return;
    setAiLoading(true);
    try {
      const res = await findEligibleSchemes(userProfile, language);
      setAiResult(res);
    } catch (e) {
      setAiResult("Could not fetch schemes right now.");
    } finally {
      setAiLoading(false);
    }
  };

  return (
    <div className="p-6 h-full flex flex-col space-y-6">
      <div className="flex justify-between items-center bg-white p-2 rounded-xl shadow-sm border border-orange-100 w-full md:w-auto">
         <div className="flex space-x-2">
            <button onClick={() => setActiveTab('directory')} className={`px-6 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'directory' ? 'bg-orange-500 text-white shadow-md' : 'text-gray-500 hover:bg-orange-50'}`}>Schemes</button>
            <button onClick={() => setActiveTab('ai')} className={`px-6 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'ai' ? 'bg-orange-500 text-white shadow-md' : 'text-gray-500 hover:bg-orange-50'}`}>Scheme Sathi (AI)</button>
         </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {activeTab === 'directory' && (
          <div className="space-y-6">
             <div className="flex flex-col md:flex-row gap-4">
                <div className="relative flex-1">
                   <input 
                     type="text" 
                     placeholder="Search schemes (e.g. Kisan, Pension, House)..." 
                     className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-400 bg-white"
                     value={search} 
                     onChange={e => setSearch(e.target.value)} 
                   />
                   <svg className="w-5 h-5 text-gray-400 absolute left-3 top-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
                </div>
                <select 
                   className="p-3 border border-gray-200 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-orange-400"
                   value={filter}
                   onChange={e => setFilter(e.target.value)}
                >
                   <option value="All">All Categories</option>
                   <option value="Agriculture">Agriculture</option>
                   <option value="Financial">Financial</option>
                   <option value="Employment">Employment</option>
                   <option value="Housing">Housing</option>
                   <option value="Health">Health</option>
                   <option value="Education">Education</option>
                </select>
             </div>
             <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredSchemes.map(scheme => (
                   <div key={scheme.id} className="bg-white rounded-2xl p-6 shadow-sm border border-orange-50 hover:shadow-md transition-shadow flex flex-col">
                      <div className="flex justify-between items-start mb-4">
                         <span className={`text-xs font-bold px-2 py-1 rounded-full uppercase tracking-wide ${
                            scheme.id.startsWith('k') ? 'bg-yellow-100 text-yellow-800' :
                            scheme.id.startsWith('tn') ? 'bg-purple-100 text-purple-800' :
                            scheme.id.startsWith('kl') ? 'bg-pink-100 text-pink-800' :
                            scheme.id.startsWith('cust') ? 'bg-emerald-100 text-emerald-800' :
                            'bg-blue-100 text-blue-800'
                         }`}>
                             {scheme.id.startsWith('k') ? 'Karnataka' : 
                              scheme.id.startsWith('tn') ? 'Tamil Nadu' : 
                              scheme.id.startsWith('kl') ? 'Kerala' : 
                              scheme.id.startsWith('cust') ? 'Panchayat' : 'Central Govt'}
                         </span>
                         <span className="bg-orange-50 text-orange-700 text-xs font-bold px-2 py-1 rounded-full uppercase tracking-wide">{scheme.category}</span>
                      </div>
                      <h3 className="text-xl font-bold text-gray-800 mb-2">{scheme.name}</h3>
                      <p className="text-gray-600 text-sm mb-4 flex-1">{scheme.description}</p>
                      <div className="space-y-3 pt-4 border-t border-gray-100">
                         <div>
                            <p className="text-xs font-bold text-gray-400 uppercase">Benefits</p>
                            <p className="text-sm font-semibold text-emerald-600">{scheme.benefits}</p>
                         </div>
                         <div>
                            <p className="text-xs font-bold text-gray-400 uppercase">Eligibility</p>
                            <p className="text-sm text-gray-700">{scheme.eligibility}</p>
                         </div>
                      </div>
                   </div>
                ))}
             </div>
             {filteredSchemes.length === 0 && (
                <div className="text-center py-12 text-gray-400">
                   No schemes found matching your criteria.
                </div>
             )}
          </div>
        )}

        {activeTab === 'ai' && (
           <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-full">
              <div className="bg-gradient-to-br from-orange-500 to-red-600 rounded-3xl p-8 text-white shadow-xl flex flex-col h-fit">
                 <h2 className="text-3xl font-bold mb-4">Scheme Sathi</h2>
                 <p className="text-orange-100 mb-6">Describe your family situation, age, occupation, and land holding. The AI will scan all Central and State schemes to find the best ones for you.</p>
                 <textarea className="w-full bg-white/10 border border-white/20 rounded-xl p-4 text-white placeholder-orange-200 focus:outline-none h-40 resize-none mb-4" placeholder="e.g. I am a 45 year old farmer in Mandya with 2 acres of land..." value={userProfile} onChange={e => setUserProfile(e.target.value)}></textarea>
                 <button onClick={handleCheckEligibility} disabled={aiLoading || !userProfile} className="bg-white text-orange-600 font-bold py-3 px-6 rounded-xl shadow-lg hover:bg-orange-50 transition-colors disabled:opacity-50 flex items-center justify-center">
                    {aiLoading ? (
                       <span className="flex items-center">
                          <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-orange-600" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                          Checking Eligibility...
                       </span>
                    ) : "Find My Schemes"}
                 </button>
              </div>

              <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-8 overflow-y-auto min-h-[400px]">
                 {aiResult ? <div className="prose prose-orange max-w-none whitespace-pre-wrap">{aiResult}</div> : <p className="text-center text-gray-400 flex flex-col items-center justify-center h-full">Enter details to generate report</p>}
              </div>
           </div>
        )}
      </div>
    </div>
  );
};
