
import React, { useState, useEffect, useMemo } from 'react';
import { Village, Language } from '../types';
import { translations } from '../translations';

interface VillageDirectoryProps {
  villages: Village[];
  selectedId: string;
  onSelect: (village: Village) => void;
  language: Language;
  title?: string;
  subtitle?: string;
}

export const VillageDirectory: React.FC<VillageDirectoryProps> = ({ villages, selectedId, onSelect, language, title, subtitle }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [showExact, setShowExact] = useState(false); // Toggle for exact seed villages
  const itemsPerPage = 50;
  
  const t = translations[language].directory;

  // Filter villages based on search and "Exact" toggle
  const filteredVillages = useMemo(() => {
      let result = villages.filter(v => 
        v.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        v.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
        v.panchayat.toLowerCase().includes(searchTerm.toLowerCase())
      );

      if (showExact) {
          result = result.filter(v => !v.id.includes('_gen_'));
      }
      
      // Sort to ensure real (seed) villages appear first
      return result.sort((a, b) => {
          const aIsGen = a.id.includes('_gen_');
          const bIsGen = b.id.includes('_gen_');
          if (aIsGen === bIsGen) return a.name.localeCompare(b.name);
          return aIsGen ? 1 : -1;
      });

  }, [villages, searchTerm, showExact]);

  // Reset to page 1 when search/filter changes
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, showExact]);

  // Pagination Logic
  const totalPages = Math.ceil(filteredVillages.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedVillages = filteredVillages.slice(startIndex, startIndex + itemsPerPage);

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= totalPages) {
        setCurrentPage(newPage);
    }
  };

  return (
    <div className="p-6 h-full flex flex-col">
      <div className="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">{title || t.title}</h1>
          <p className="text-gray-500">
             {subtitle || t.subtitle} ({filteredVillages.length.toLocaleString()} villages found)
          </p>
        </div>
        <div className="flex gap-3 w-full md:w-auto">
            {/* Toggle for Exact Villages */}
            <button 
                onClick={() => setShowExact(!showExact)}
                className={`px-4 py-2 rounded-xl text-sm font-bold border transition-colors ${showExact ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-gray-600 border-gray-300 hover:bg-gray-50'}`}
                title="Show only original registered villages, hiding generated simulations"
            >
                {showExact ? 'Showing Exact Only' : 'Show All'}
            </button>

            <div className="relative flex-1 md:w-64">
                <input 
                    type="text" 
                    placeholder={t.searchPlaceholder}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
                <svg className="w-5 h-5 text-gray-400 absolute left-3 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
            </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto bg-white rounded-3xl shadow-sm border border-gray-100 flex flex-col">
        <div className="overflow-auto flex-1">
            <table className="w-full text-left border-collapse">
            <thead className="bg-gray-50 sticky top-0 z-10 shadow-sm">
                <tr>
                <th className="p-4 text-xs font-bold text-gray-500 uppercase tracking-wider">{t.headers.name}</th>
                <th className="p-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Panchayat</th>
                <th className="p-4 text-xs font-bold text-gray-500 uppercase tracking-wider">{t.headers.location}</th>
                <th className="p-4 text-xs font-bold text-gray-500 uppercase tracking-wider">{t.headers.population}</th>
                <th className="p-4 text-xs font-bold text-gray-500 uppercase tracking-wider">{t.headers.literacy}</th>
                <th className="p-4 text-xs font-bold text-gray-500 uppercase tracking-wider">{t.headers.pension}</th>
                <th className="p-4 text-xs font-bold text-gray-500 uppercase tracking-wider text-right">{t.headers.action}</th>
                </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
                {paginatedVillages.map((village) => (
                <tr key={village.id} className={`hover:bg-gray-50 transition-colors ${selectedId === village.id ? 'bg-emerald-50/50' : ''}`}>
                    <td className="p-4">
                        <div className="font-bold text-gray-800">{village.name}</div>
                        {!village.id.includes('_gen_') && (
                            <span className="inline-block mt-1 px-1.5 py-0.5 bg-blue-100 text-blue-700 text-[9px] font-bold rounded uppercase tracking-wide">Primary</span>
                        )}
                        {selectedId === village.id && (
                            <span className="inline-block mt-1 ml-1 px-2 py-0.5 bg-emerald-100 text-emerald-700 text-[10px] font-bold rounded-full">{t.status.active}</span>
                        )}
                    </td>
                    <td className="p-4 text-sm text-gray-600 font-medium">{village.panchayat}</td>
                    <td className="p-4 text-sm text-gray-600">{village.location}</td>
                    <td className="p-4 text-sm text-gray-800 font-medium">{village.population.toLocaleString()}</td>
                    <td className="p-4">
                    <div className="flex items-center">
                        <span className="text-sm font-bold text-gray-800 mr-2">{village.literacyRate}%</span>
                        <div className="w-16 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                        <div className="h-full bg-blue-500 rounded-full" style={{ width: `${village.literacyRate}%` }}></div>
                        </div>
                    </div>
                    </td>
                    <td className="p-4">
                    <div className="text-sm">
                        <span className="font-bold text-gray-800">{village.pensionData?.total.toLocaleString() ?? 0}</span>
                        <span className="text-gray-400 text-xs ml-1">{t.pensionLabels.total}</span>
                    </div>
                    <div className="flex gap-2 mt-1 text-[10px] text-gray-500">
                        <span title={t.pensionLabels.old} className="bg-orange-50 text-orange-700 px-1.5 py-0.5 rounded">{t.pensionLabels.old}: {village.pensionData?.oldAge ?? 0}</span>
                        <span title={t.pensionLabels.widow} className="bg-pink-50 text-pink-700 px-1.5 py-0.5 rounded">{t.pensionLabels.widow}: {village.pensionData?.widow ?? 0}</span>
                        <span title={t.pensionLabels.disability} className="bg-purple-50 text-purple-700 px-1.5 py-0.5 rounded">{t.pensionLabels.disability}: {village.pensionData?.disability ?? 0}</span>
                    </div>
                    </td>
                    <td className="p-4 text-right">
                    <button 
                        onClick={() => onSelect(village)}
                        disabled={selectedId === village.id}
                        className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${
                        selectedId === village.id 
                        ? 'bg-gray-200 text-gray-400 cursor-default' 
                        : 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-md hover:shadow-lg'
                        }`}
                    >
                        {selectedId === village.id ? t.status.managing : t.status.manage}
                    </button>
                    </td>
                </tr>
                ))}
            </tbody>
            </table>
            
            {filteredVillages.length === 0 && (
            <div className="p-12 text-center text-gray-400">
                <p>{t.pagination.noResults} "{searchTerm}"</p>
                {showExact && <p className="text-sm mt-2 text-gray-500">Try disabling "Showing Exact Only" to see all records.</p>}
            </div>
            )}
        </div>

        {/* Pagination Controls */}
        <div className="p-4 border-t border-gray-100 bg-gray-50 rounded-b-3xl flex justify-between items-center">
            <span className="text-sm text-gray-500">
                {t.pagination.page} {currentPage} {t.pagination.of} {totalPages || 1}
            </span>
            <div className="flex space-x-2">
                <button 
                    onClick={() => handlePageChange(currentPage - 1)}
                    disabled={currentPage === 1}
                    className="px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm font-medium text-gray-600 hover:bg-gray-50 disabled:opacity-50"
                >
                    {t.pagination.prev}
                </button>
                <button 
                    onClick={() => handlePageChange(currentPage + 1)}
                    disabled={currentPage === totalPages || totalPages === 0}
                    className="px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm font-medium text-gray-600 hover:bg-gray-50 disabled:opacity-50"
                >
                    {t.pagination.next}
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};
