
import React, { useState } from 'react';
import { optimizeWaterUsage, getCropWaterAdvice } from '../services/geminiService';
import { Village, Language } from '../types';

export const WaterManagement: React.FC<{ village: Village; language: Language }> = ({ village, language }) => {
    const [advice, setAdvice] = useState('');
    const [loading, setLoading] = useState(false);
    const [cropName, setCropName] = useState('');
    const [season, setSeason] = useState('');
    const [cropAdvice, setCropAdvice] = useState('');
    const [cropLoading, setCropLoading] = useState(false);

    const [tankLevel] = useState(72);
    const [flowRate] = useState(12.5);
    const [phLevel] = useState(7.2);

    const getAIAdvice = async () => {
        setLoading(true);
        try {
            const context = `Village: ${village.name}. Tank Level: ${tankLevel}%, Flow Rate: ${flowRate} L/min, pH: ${phLevel}. 
            Recent rainfall was low. Village population ${village.population}. Agriculture demand is high.`;
            const res = await optimizeWaterUsage(context, language);
            setAdvice(res);
        } catch(e) { setAdvice("Could not generate advice."); }
        finally { setLoading(false); }
    };

    const handleCropAdvice = async () => {
        if (!cropName || !season) return;
        setCropLoading(true);
        try {
            const res = await getCropWaterAdvice(cropName, season, language);
            setCropAdvice(res);
        } catch(e) { setCropAdvice("Analysis failed."); }
        finally { setCropLoading(false); }
    };

    return (
        <div className="p-6 h-full flex flex-col space-y-6 overflow-y-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Visual Monitoring (Mock UI) */}
                <div className="space-y-6">
                    <div className="bg-white rounded-3xl p-8 shadow-sm border border-cyan-100 relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-400/10 rounded-full -mr-8 -mt-8 blur-2xl"></div>
                        <h2 className="text-2xl font-bold text-gray-800 mb-8">{village.name} Reservoir</h2>
                        <div className="flex items-center justify-center mb-8">
                            <div className="w-48 h-48 rounded-full border-8 border-gray-100 relative overflow-hidden shadow-inner bg-gray-50">
                                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-cyan-600 to-cyan-400 transition-all duration-1000 ease-in-out" style={{ height: `${tankLevel}%` }}></div>
                                <div className="absolute inset-0 flex items-center justify-center flex-col z-10">
                                    <span className="text-4xl font-bold text-gray-800 drop-shadow-sm">{tankLevel}%</span>
                                    <span className="text-xs text-gray-500 font-medium bg-white/50 px-2 py-1 rounded-full mt-1">Capacity</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* AI General Optimization */}
                <div className="bg-gradient-to-br from-cyan-900 to-blue-900 rounded-3xl p-8 text-white flex flex-col shadow-xl">
                    <h2 className="text-2xl font-bold mb-2">Smart Water AI</h2>
                    <div className="flex-1 bg-white/10 rounded-2xl p-6 mb-6 overflow-y-auto backdrop-blur-sm border border-white/10 max-h-64">
                        {loading ? <div className="animate-pulse">Processing...</div> : advice ? <div className="prose prose-invert prose-sm whitespace-pre-wrap">{advice}</div> : <div className="text-cyan-200/50">Ready to analyze</div>}
                    </div>
                    <button onClick={getAIAdvice} disabled={loading} className="w-full bg-cyan-500 hover:bg-cyan-400 text-white font-bold py-4 rounded-xl shadow-lg transition-transform transform hover:scale-[1.02] active:scale-95 disabled:opacity-50">
                        {loading ? 'Processing...' : 'Optimize Reservoir Usage'}
                    </button>
                </div>
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-sm border border-cyan-100">
                 <h2 className="text-2xl font-bold text-gray-800 mb-2">Precision Irrigation Guide</h2>
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                     <div className="space-y-4">
                         <div>
                            <label className="text-xs font-bold text-gray-500 uppercase">Crop Name</label>
                            <input type="text" className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 mt-1 focus:ring-2 focus:ring-cyan-500 outline-none" placeholder="e.g. Tomato" value={cropName} onChange={(e) => setCropName(e.target.value)} />
                         </div>
                         <div>
                            <label className="text-xs font-bold text-gray-500 uppercase">Season</label>
                            <select className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 mt-1 focus:ring-2 focus:ring-cyan-500 outline-none" value={season} onChange={(e) => setSeason(e.target.value)}>
                                <option value="">Select Season</option>
                                <option value="Spring">Spring</option>
                                <option value="Summer">Summer</option>
                                <option value="Monsoon">Monsoon</option>
                                <option value="Winter">Winter</option>
                            </select>
                         </div>
                         <button onClick={handleCropAdvice} disabled={cropLoading || !cropName || !season} className="w-full bg-cyan-600 text-white font-bold py-3 rounded-xl hover:bg-cyan-700 transition-colors disabled:opacity-50">
                            {cropLoading ? 'Generating Guide...' : 'Get Water Schedule'}
                         </button>
                     </div>
                     <div className="md:col-span-2 bg-cyan-50/50 rounded-2xl p-6 border border-cyan-100 min-h-[200px] max-h-[300px] overflow-y-auto">
                        {cropAdvice ? <div className="prose prose-cyan max-w-none whitespace-pre-wrap">{cropAdvice}</div> : <div className="text-gray-400">Select crop and season</div>}
                     </div>
                 </div>
            </div>
        </div>
    );
};
