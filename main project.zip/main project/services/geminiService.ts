
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { PlanProposal, MarketData, QuizItem, Language } from "../types";

// Initialize the client
// NOTE: API Key is injected via process.env.API_KEY automatically in the environment
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const getLangPrompt = (lang: Language) => {
  if (lang === 'kn') return "IMPORTANT: Respond ONLY in Kannada (Kannada script).";
  if (lang === 'hi') return "IMPORTANT: Respond ONLY in Hindi (Devanagari script).";
  return "Respond in English.";
};

/**
 * Generates an infrastructure plan using Thinking Config for deep reasoning.
 */
export const generateVillagePlan = async (
  prompt: string,
  budget: number,
  language: Language
): Promise<PlanProposal> => {
  const model = "gemini-2.5-flash"; 
  const langInstruction = getLangPrompt(language);
  
  const response = await ai.models.generateContent({
    model,
    contents: `You are an expert city planner specializing in sustainable rural development. 
    Analyze this request: "${prompt}" with a budget of $${budget}.
    Provide a detailed plan.
    ${langInstruction} 
    Note: Keep the JSON keys in English, but the values (title, description, impact, riskAssessment) should be in ${language === 'en' ? 'English' : language === 'kn' ? 'Kannada' : 'Hindi'}.`,
    config: {
      thinkingConfig: { thinkingBudget: 1024 },
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING },
          impact: { type: Type.STRING },
          riskAssessment: { type: Type.STRING },
        },
        required: ["title", "description", "impact", "riskAssessment"],
      },
    },
  });

  const text = response.text;
  if (!text) throw new Error("No plan generated");
  const data = JSON.parse(text);
  return { ...data, budget };
};

export const generatePlanVisualization = async (description: string): Promise<string> => {
  const model = "gemini-2.5-flash-image";
  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        { text: `Photorealistic architectural render of: ${description}. Rural village setting, sunny day, 4k quality.` }
      ]
    },
    config: { imageConfig: { aspectRatio: "16:9" } }
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  throw new Error("No image generated");
};

export const analyzeCropHealth = async (
  base64Image: string,
  mimeType: string,
  searchMarket: boolean,
  language: Language
): Promise<string> => {
  const model = searchMarket ? "gemini-3-pro-image-preview" : "gemini-2.5-flash"; 
  const tools = searchMarket ? [{ googleSearch: {} }] : undefined;
  const langInstruction = getLangPrompt(language);

  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        { inlineData: { data: base64Image, mimeType: mimeType } },
        {
          text: searchMarket 
            ? `Analyze this plant. If healthy, search for market price. ${langInstruction}` 
            : `Identify this plant, diagnose diseases, and provide remediation. ${langInstruction}`,
        },
      ],
    },
    config: { tools },
  });

  let output = response.text || "Analysis failed.";
  return output;
};

export const recommendCrops = async (soil: string, season: string, location: string, language: Language): Promise<string> => {
    const model = "gemini-2.5-flash";
    const langInstruction = getLangPrompt(language);
    const response = await ai.models.generateContent({
        model,
        contents: `I have ${soil} soil in ${location} during ${season}. What crops should I plant? 
        Consider water usage, yield, and market demand. Provide a detailed strategy. ${langInstruction}`,
        config: { thinkingConfig: { thinkingBudget: 2048 } }
    });
    return response.text || "Could not generate recommendation.";
};

export const predictMarketTrends = async (crop: string, location: string, language: Language): Promise<MarketData> => {
    const model = "gemini-2.5-flash";
    const langInstruction = getLangPrompt(language);
    
    const response = await ai.models.generateContent({
        model,
        contents: `Search for the current market price of ${crop} in ${location} and global markets. 
        Predict price trend for next 7 days.
        ${langInstruction}
        
        Return the response in this specific format (do not use markdown code blocks):
        PRICE: [Current Price String]
        ANALYSIS: [Detailed analysis in ${language === 'kn' ? 'Kannada' : language === 'hi' ? 'Hindi' : 'English'}]
        FORECAST: [Day1], [Day2], [Day3], [Day4], [Day5], [Day6], [Day7] (Numbers only)
        `,
        config: { tools: [{ googleSearch: {} }] }
    });

    const text = response.text || "";
    const priceMatch = text.match(/PRICE:\s*(.+)/);
    const analysisMatch = text.match(/ANALYSIS:\s*([\s\S]+?)FORECAST:/);
    const forecastMatch = text.match(/FORECAST:\s*(.+)/);
    
    const currentPrice = priceMatch ? priceMatch[1].trim() : "N/A";
    const analysis = analysisMatch ? analysisMatch[1].trim() : text;
    
    const forecastArr = forecastMatch 
        ? forecastMatch[1].split(',').map(n => parseFloat(n.trim()) || 0) 
        : [0,0,0,0,0,0,0];

    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const forecast = days.map((day, i) => ({ day, price: forecastArr[i] || 0 }));
    const news = (response.candidates?.[0]?.groundingMetadata?.groundingChunks || [])
        .map(c => ({ title: c.web?.title || "News Source", url: c.web?.uri || "#" }))
        .slice(0, 3);

    return { crop, currentPrice, analysis, forecast, news };
};

export const optimizeWaterUsage = async (dataContext: string, language: Language): Promise<string> => {
    const model = "gemini-2.5-flash";
    const langInstruction = getLangPrompt(language);
    const response = await ai.models.generateContent({
        model,
        contents: `Analyze this water usage data: "${dataContext}". Provide 3 actionable tips to conserve water. ${langInstruction}`,
    });
    return response.text || "No advice available.";
};

export const getCropWaterAdvice = async (crop: string, season: string, language: Language): Promise<string> => {
    const model = "gemini-2.5-flash";
    const langInstruction = getLangPrompt(language);
    const response = await ai.models.generateContent({
        model,
        contents: `Provide a detailed water management schedule for ${crop} during ${season}. ${langInstruction}`,
    });
    return response.text || "No advice available.";
};

export const analyzeSymptoms = async (symptoms: string, language: Language): Promise<string> => {
    const model = "gemini-2.5-flash";
    const langInstruction = getLangPrompt(language);
    const response = await ai.models.generateContent({
        model,
        contents: `User symptoms: "${symptoms}". Act as a village health assistant. Provide triage. ${langInstruction}`,
    });
    return response.text || "Could not analyze symptoms.";
};

export const findNearbyResources = async (query: string, lat: number, lng: number, language: Language): Promise<string> => {
  const model = "gemini-2.5-flash";
  const langInstruction = getLangPrompt(language);
  const response = await ai.models.generateContent({
    model,
    contents: `${query}. ${langInstruction}`,
    config: {
      tools: [{ googleMaps: {} }],
      toolConfig: { retrievalConfig: { latLng: { latitude: lat, longitude: lng } } }
    }
  });
  return response.text || "No location data found.";
};

export const findHospitals = async (location: string, language: Language): Promise<string> => {
  const model = "gemini-2.5-flash";
  const langInstruction = getLangPrompt(language);
  const response = await ai.models.generateContent({
    model,
    contents: `List nearest hospitals to "${location}". ${langInstruction}`,
    config: { tools: [{ googleMaps: {} }] }
  });
  return response.text || "No hospitals found.";
};

export const createLessonPlan = async (topic: string, level: string, language: Language): Promise<string> => {
  const model = "gemini-2.5-flash";
  const langInstruction = getLangPrompt(language);
  const response = await ai.models.generateContent({
    model,
    contents: `Create a lesson plan for level: ${level} regarding: "${topic}". ${langInstruction}`,
    config: { thinkingConfig: { thinkingBudget: 2048 } }
  });
  return response.text || "Could not create lesson plan.";
};

export const solveHomework = async (base64Image: string, mimeType: string, language: Language): Promise<string> => {
  const model = "gemini-2.5-flash";
  const langInstruction = getLangPrompt(language);
  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        { inlineData: { data: base64Image, mimeType: mimeType } },
        { text: `Act as a tutor. Explain the solution to this problem step-by-step. ${langInstruction}` }
      ]
    }
  });
  return response.text || "Could not solve problem.";
};

export const generateEducationalImage = async (prompt: string): Promise<string> => {
  // Images are language agnostic, but prompt translation happens implicitly by model understanding
  const model = "gemini-2.5-flash-image";
  const response = await ai.models.generateContent({
    model,
    contents: { parts: [{ text: `Educational diagram of: ${prompt}. Clear, textbook quality.` }] },
    config: { imageConfig: { aspectRatio: "4:3" } }
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
  }
  const text = response.text;
  if (text) throw new Error(`AI Refusal: ${text}`);
  throw new Error("No image generated");
};

export const generateQuiz = async (topic: string, level: string, language: Language): Promise<QuizItem[]> => {
  const model = "gemini-2.5-flash";
  // We need the schema keys to remain English for parsing, but content to be translated
  const langInstruction = language === 'en' ? '' : `Write the 'question', 'options', and 'explanation' values in ${language === 'kn' ? 'Kannada' : 'Hindi'}.`;
  
  const response = await ai.models.generateContent({
    model,
    contents: `Create a 5-question multiple choice quiz about "${topic}" for level "${level}". ${langInstruction}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            question: { type: Type.STRING },
            options: { type: Type.ARRAY, items: { type: Type.STRING } },
            correctAnswer: { type: Type.INTEGER },
            explanation: { type: Type.STRING }
          },
          required: ["question", "options", "correctAnswer", "explanation"]
        }
      }
    }
  });
  
  const text = response.text;
  if (!text) return [];
  return JSON.parse(text) as QuizItem[];
};

export const generateSpeech = async (text: string): Promise<string> => {
  const model = "gemini-2.5-flash-preview-tts";
  const response = await ai.models.generateContent({
    model,
    contents: { parts: [{ text }] },
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } }
    }
  });
  
  const audioData = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!audioData) throw new Error("No audio generated");
  return audioData;
};

export const findEligibleSchemes = async (userProfile: string, language: Language): Promise<string> => {
  const model = "gemini-2.5-flash";
  const langInstruction = getLangPrompt(language);
  const response = await ai.models.generateContent({
    model,
    contents: `Act as a government scheme expert. Analyze profile: "${userProfile}".
    Search for eligible schemes in Karnataka/India.
    Return 3-5 schemes with benefits and eligibility.
    ${langInstruction}`,
    config: { tools: [{ googleSearch: {} }] }
  });

  const text = response.text || "No schemes found.";
  const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
  if (chunks) {
      const links = chunks
        .flatMap(c => c.web?.uri ? [`[${c.web.title || 'Link'}](${c.web.uri})`] : [])
        .slice(0, 3)
        .join(', ');
      if (links) return text + `\n\n**Links:** ${links}`;
  }
  return text;
};

export { ai };
